#!/usr/bin/env bash
set -euo pipefail
package_dir="$(cd -- "$(dirname -- "${BASH_SOURCE[0]}")" && pwd)"
cd /workspaces/Zervan-Central
[ "$(git branch --show-current)" = main ] || { echo 'STOP: checkout main first'; exit 1; }
[ -z "$(git status --porcelain)" ] || { echo 'STOP: preserve or commit existing local work first'; git status --short; exit 1; }
git pull --ff-only origin main
base_commit=f09fc1768d4924992134602c8984e4ea5485d31a
correction_commit=b6cc316118c241256b175ceec78b9a406a1cc99c
git merge-base --is-ancestor "$base_commit" HEAD || { echo 'STOP: current main is not based on the verified source'; exit 1; }
git bundle verify "$package_dir/correction.bundle"
git fetch "$package_dir/correction.bundle" HEAD
if git merge-base --is-ancestor "$correction_commit" HEAD; then
  echo 'Correction commit is already present.'
else
  git cherry-pick --no-commit "$correction_commit"
fi
python3 -c 'import jsonschema' || python3 -m pip install jsonschema
make check
# Historical frozen bytes contain Markdown hard breaks and EOF spacing.
# Preserve them; the new contract and implementation were checked separately.
git -c core.whitespace=-blank-at-eol,-blank-at-eof diff --cached --check
if ! git diff --cached --quiet; then
  git commit -m 'Promote mandatory Zervan middleware routing contract' -m 'Human Gate-authorized publication. Preserve frozen and staged predecessors; require the admitted complete middleware contract in canonical initialization and development returns. make check and adversarial admission checks passed. No independent credential issuance or host enforcement claim.'
fi
git push origin HEAD:main
local_commit="$(git rev-parse HEAD)"
remote_commit="$(git ls-remote origin refs/heads/main | cut -f1)"
[ "$local_commit" = "$remote_commit" ] || { echo 'STOP: remote main differs after push'; exit 1; }
printf 'VERIFIED MAIN: %s\n' "$remote_commit"
