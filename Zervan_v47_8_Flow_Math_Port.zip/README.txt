v47.8 flow-math port for Codespaces main

The script applies the additive flow-math files onto a clean, synchronized main, updates the admission hashes to the exact main parent, commits directly to main, pushes, and confirms the remote main SHA. It does not run tests. It stops without changing the repository if the branch is not main, the worktree is dirty, or the expected v47.8 baseline has changed.

In Codespaces, upload this ZIP, then from the repository root run:

  unzip -o Zervan_v47_8_Flow_Math_Port.zip -d /tmp/zervan-flow-math-port
  bash /tmp/zervan-flow-math-port/APPLY_FLOW_MATH_V47_8.sh

