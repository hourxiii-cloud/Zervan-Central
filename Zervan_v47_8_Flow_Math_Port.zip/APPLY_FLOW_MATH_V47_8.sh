#!/usr/bin/env bash
set -euo pipefail

repo_root="$(git rev-parse --show-toplevel)"
cd "$repo_root"
if [[ "$(git branch --show-current)" != "main" ]]; then
  echo "STOP: switch to main before applying this port." >&2
  exit 1
fi
if [[ -n "$(git status --porcelain)" ]]; then
  echo "STOP: worktree is not clean; preserving all existing changes." >&2
  git status --short
  exit 1
fi
script_dir="$(cd "$(dirname "${BASH_SOURCE[0]}")" && pwd)"
test -d "$script_dir/payload"
git fetch origin main
git pull --ff-only origin main
python3 - "$script_dir/payload" "$repo_root" <<'PYCODE'
import hashlib, json, pathlib, re, shutil, subprocess, sys
payload=pathlib.Path(sys.argv[1]); root=pathlib.Path(sys.argv[2])
version_path=root/'VERSION.json'
version=json.loads(version_path.read_text())
if version.get('version')!='vTemporal.47.8.0' or 'flow_math_admission' in version:
    raise SystemExit('STOP: current main is not an untouched v47.8 flow-math baseline.')
if (root/'canonical/geometry/FLOW_MATH_ADMISSION.json').exists():
    raise SystemExit('STOP: flow-math admission already exists on main.')
for p in payload.rglob('*'):
    if p.is_file():
        rel=p.relative_to(payload); dest=root/rel
        dest.parent.mkdir(parents=True,exist_ok=True)
        shutil.copy2(p,dest)
parent=subprocess.check_output(['git','rev-parse','HEAD'],cwd=root,text=True).strip()
# Bind all provenance to the synchronized main head at application time.
math_path=root/'canonical/geometry/RELATIONAL_FLOW_MATHEMATICS.md'
s=math_path.read_text()
s=re.sub(r'Port baseline: vTemporal\.47\.8\.0 main `[^`]+`',f'Port baseline: vTemporal.47.8.0 main `{parent}`',s)
math_path.write_text(s)
receipt=root/'verification/v47.8/FLOW_MATH_PORT_RECEIPT.md'
s=receipt.read_text()
s=re.sub(r'Port base: live `main` at `[^`]+`',f'Port base: live `main` at `{parent}`',s)
receipt.write_text(s)
admission_path=root/'canonical/geometry/FLOW_MATH_ADMISSION.json'
ad=json.loads(admission_path.read_text()); ad['baseline_commit']=parent
for item in ad['payloads']:
    b=(root/item['path']).read_bytes()
    item['size_bytes']=len(b); item['sha256']=hashlib.sha256(b).hexdigest()
admission_path.write_text(json.dumps(ad,indent=2)+'\n')
PYCODE
git add -- VERSION.json Makefile canonical/ZERVAN_v47_8_CANONICAL_ENTRY.md \
  canonical/geometry/FLOW_MATH_ADMISSION.json \
  canonical/geometry/RELATIONAL_FLOW_MATHEMATICS.md \
  verification/geometry/FLOW_MATH_QUALIFICATION_RECEIPT.md \
  verification/v47.8/FLOW_MATH_PORT_RECEIPT.md \
  tools/relational_flow_math.py tools/validate_flow_math_admission.py \
  tests/test_relational_flow_math.py tests/test_flow_math_admission.py
git commit -m "Add v47.8 relational flow math supplement"
git push origin main
expected="$(git rev-parse HEAD)"
remote="$(git ls-remote origin refs/heads/main | awk '{print $1}')"
if [[ "$remote" != "$expected" ]]; then
  echo "ERROR: remote main verification did not match local HEAD." >&2
  exit 1
fi
printf 'PUSH_VERIFIED branch=main commit=%s\n' "$expected"
