#!/usr/bin/env bash
set -euo pipefail
repo=$(realpath -- "${1:?Pass the repository root}")
package=$(cd -- "$(dirname -- "${BASH_SOURCE[0]}")" && pwd)
[[ "$(git -C "$repo" rev-parse --show-toplevel)" == "$repo" ]] || {
  echo 'Pass the Git repository root.' >&2; exit 2;
}
[[ "$(git -C "$repo" branch --show-current)" == development/v42.5.2 ]] || {
  echo 'Switch to development/v42.5.2 before applying this increment.' >&2; exit 2;
}
git -C "$repo" merge-base --is-ancestor 65df9336f869e5f0c82ded5e50c8c7dca9f7f2d5 HEAD || {
  echo 'The verified v42.5.1 baseline is not in this branch history.' >&2; exit 2;
}
git -C "$repo" diff --quiet && git -C "$repo" diff --cached --quiet || {
  echo 'Commit or separately preserve tracked working changes before applying.' >&2; exit 2;
}
(cd "$package" && sha256sum -c SHA256SUMS)
(cd "$repo" && sha256sum -c "$package/PREREQUISITES.sha256")
# Preflight every destination before copying anything. Equal files permit reruns.
python3 - "$package" "$repo" <<'PY'
from pathlib import Path
import sys
package, repo = map(Path, sys.argv[1:])
paths = (package/'FILES').read_text().splitlines()
for relative in paths:
    path = Path(relative)
    if path.is_absolute() or '..' in path.parts or not path.parts:
        raise SystemExit('Unsafe manifest path: '+relative)
    dest = repo/path
    if not dest.resolve().is_relative_to(repo):
        raise SystemExit('Destination escapes checkout: '+relative)
    if dest.is_symlink() or (dest.exists() and (not dest.is_file() or dest.read_bytes() != (package/'payload'/path).read_bytes())):
        raise SystemExit('Existing different file; no changes applied: '+relative)
for relative in paths:
    dest = repo/relative
    dest.parent.mkdir(parents=True, exist_ok=True)
    if not dest.exists():
        dest.write_bytes((package/'payload'/relative).read_bytes())
print('Applied World/Box increment to development/v42.5.2. No commit or promotion performed.')
PY
