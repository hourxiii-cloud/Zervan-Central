#!/usr/bin/env bash
set -euo pipefail

target_repo=${1:?Pass the Zervan-Central checkout path}
package_dir=$(cd -- "$(dirname -- "${BASH_SOURCE[0]}")" && pwd)
base_commit=65df9336f869e5f0c82ded5e50c8c7dca9f7f2d5

git -C "$target_repo" rev-parse --is-inside-work-tree >/dev/null
branch=$(git -C "$target_repo" branch --show-current)
case "$branch" in
  main|master|'') echo "Refusing to install on $branch; switch to a development branch." >&2; exit 2 ;;
esac
git -C "$target_repo" merge-base --is-ancestor "$base_commit" HEAD || {
  echo "Base $base_commit is not in this checkout's history." >&2; exit 2;
}

cd "$package_dir"
sha256sum -c SHA256SUMS
while IFS= read -r relative_path; do
  [[ -n "$relative_path" ]] || continue
  destination="$target_repo/$relative_path"
  if [[ -e "$destination" ]]; then
    echo "Refusing to overwrite $relative_path" >&2
    exit 2
  fi
done < FILES
while IFS= read -r relative_path; do
  [[ -n "$relative_path" ]] || continue
  mkdir -p "$(dirname -- "$target_repo/$relative_path")"
  cp -- "payload/$relative_path" "$target_repo/$relative_path"
done < FILES
echo "Installed candidate files on $branch; review and validate before any commit."
