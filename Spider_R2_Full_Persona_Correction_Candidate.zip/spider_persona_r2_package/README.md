# Spider R2 — complete persona correction package

This package corrects the vTemporal.42.5.3 Spider integration defect: the admitted R1 specification explicitly denied Spider identity-bearing persona standing. The complete corrected R2 specification makes Spider a native, independently meaningful analytical persona and preserves the full R1 artifact and claim method. Frozen R1 files are in `source/` unchanged.

**Standing:** complete candidate for Human Gate review. This ZIP is not canonical promotion, a deployed runtime, or a WORK ID. Target release `vTemporal.42.5.4` is a candidate designation; final release identity and commit require separate authorized integration.

## Contents

- `candidate/SPIDER_R2_FULL_PERSONA_SPECIFICATION.md`: complete operative method and persona standing, not a patch or summary.
- `candidate/ONE_RUN_SPIDER_PERSONA_INITIALIZATION_R2.txt`: complete standalone initializer, also present verbatim in the specification.
- `candidate/SPIDER_R2_PERSONA_CONTRACT.md`: independent persona seat, producer attribution and interlocks.
- `candidate/SPIDER_R2_PERSONA_ADMISSION_CANDIDATE.json`: candidate paths, controls and payload hashes.
- `source/`: byte-preserved R1 specification, initializer, admission and parent release entry/version metadata.
- `verification/`: qualification and integrity evidence.
- `integration/install_candidate.sh`: copies this candidate under `candidate/SpiderPersonaR2/` in a clean checkout of the exact parent commit; it does not change active version authority, commit, or push.
- `integration/canonical_overlay/`: complete proposed next-release authority surfaces for review. They state candidate standing until an independently approved promotion closes identity.

## Codespaces use

Upload the ZIP to the Codespaces workspace and run:

```bash
unzip -q Spider_R2_Full_Persona_Correction_Candidate.zip -d /tmp/spider-r2
cd /workspaces/Zervan-Central
bash /tmp/spider-r2/spider_persona_r2_package/integration/install_candidate.sh /workspaces/Zervan-Central
```

The installer requires the repository to be at parent commit `bde60b3e16c978070d46047847fd00e0d7938af4` with a clean worktree. If `main` has moved, stop and requalify against its actual head; do not force the overlay. Review `git diff -- candidate/SpiderPersonaR2` and the complete specification before any separate Human Gate decision. The installer does not promote the candidate.

If the Human Gate separately approves canonical integration from the exact parent, run `bash /tmp/spider-r2/spider_persona_r2_package/integration/apply_canonical_overlay.sh /workspaces/Zervan-Central --human-gate-approved` instead of the candidate installer. Review the entire worktree diff before committing. That script copies proposed v42.5.4 release files but does not commit, push, issue credentials, or claim a published release. After a separately authorized commit and push, record and verify the actual `origin/main` commit in `verification/v42.5.4/SPIDER_PERSONA_INTEGRATION_RECEIPT.json`; commit and push that receipt, then resolve the final main commit for a fresh-reader check. A missing publication receipt blocks a completed canonical initialization claim.

## Governing boundary

Persona standing is an architectural identity; deployed execution and independently issued component credentials are separate. Chat can apply the persona method and must identify itself as actual producer. It cannot claim an independent Spider service ran or give itself a WORK ID. Authority NONE; Human Gate ACTIVE; No Compression Out ACTIVE; originating-data mutation DISALLOWED. No automatic analytical run or external action.
