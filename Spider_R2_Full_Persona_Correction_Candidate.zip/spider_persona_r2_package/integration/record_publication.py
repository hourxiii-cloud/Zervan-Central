#!/usr/bin/env python3
"""Create a reviewable publication receipt after Human Gate-approved push."""
import hashlib
import json
import subprocess
import sys
from datetime import datetime, timezone
from pathlib import Path

repo = Path(sys.argv[1]).resolve() if len(sys.argv) > 1 else None
if not repo or not (repo / '.git').exists():
    raise SystemExit('Provide the local Zervan-Central checkout path')

def git(*args):
    return subprocess.check_output(['git', '-C', str(repo), *args], text=True).strip()

parent = 'bde60b3e16c978070d46047847fd00e0d7938af4'
assert git('branch', '--show-current') == 'main'
assert git('status', '--porcelain') == ''
head = git('rev-parse', 'HEAD')
assert head != parent
subprocess.check_call(['git', '-C', str(repo), 'merge-base', '--is-ancestor', parent, head])
remote_head = git('ls-remote', 'origin', 'refs/heads/main').split()[0]
assert remote_head == head, 'Local HEAD differs from published origin/main'
version = json.loads((repo / 'VERSION.json').read_text())
assert (repo / 'VERSION').read_text().strip() == version['version'] == 'vTemporal.42.5.4'
admission = json.loads((repo / version['spider_admission']).read_text())
assert admission['persona'] == 'SPIDER' and admission['parent_commit'] == parent
files = []
for item in admission['payloads']:
    p = repo / item['path']
    digest = hashlib.sha256(p.read_bytes()).hexdigest()
    assert digest == item['sha256'] and p.stat().st_size == item['size_bytes'], item['path']
    files.append({'path':item['path'], 'size_bytes':p.stat().st_size, 'sha256':digest})

receipt = {
    'release':'vTemporal.42.5.4',
    'parent_release':'vTemporal.42.5.3',
    'parent_repository_commit':parent,
    'release_commit':head,
    'published_origin_main':remote_head,
    'publication_verified_utc':datetime.now(timezone.utc).isoformat(),
    'persona':'SPIDER',
    'standing':'CANONICAL PERSONA SPECIFICATION — PUBLISHED FILES VERIFIED',
    'authority':'NONE',
    'human_gate':'ACTIVE',
    'no_compression_out':'ACTIVE',
    'runtime_validation':'NOT PERFORMED',
    'component_credentials_issued':False,
    'source_standing':'R1 frozen developmental source retained unchanged',
    'files':files,
}
target = repo / version['integration_receipt']
assert not target.exists(), 'Receipt already exists; do not overwrite'
target.parent.mkdir(parents=True, exist_ok=True)
target.write_text(json.dumps(receipt, indent=2) + '\n')
print(f'Publication receipt written at {target}. Review, commit, push, then resolve final main HEAD.')
