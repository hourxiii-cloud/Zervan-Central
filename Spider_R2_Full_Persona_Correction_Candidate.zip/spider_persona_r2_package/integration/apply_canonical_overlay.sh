#!/usr/bin/env bash
set -euo pipefail

repo_dir=${1:?Provide the local Zervan-Central checkout path}
approval=${2:-}
test "$approval" = --human-gate-approved || { printf '%s\n' 'Explicit --human-gate-approved argument required.' >&2; exit 2; }
package_dir=$(cd "$(dirname "${BASH_SOURCE[0]}")/.." && pwd)
expected_head=bde60b3e16c978070d46047847fd00e0d7938af4

test "$(git -C "$repo_dir" rev-parse --show-toplevel)" = "$(cd "$repo_dir" && pwd)"
test "$(git -C "$repo_dir" branch --show-current)" = main
test "$(git -C "$repo_dir" rev-parse HEAD)" = "$expected_head"
test -z "$(git -C "$repo_dir" status --porcelain)"
python3 "$package_dir/verification/validate_package.py" "$package_dir"

overlay="$package_dir/integration/canonical_overlay"
for relative in VERSION VERSION.json VERSION_AUTHORITY.md call/INITIATION_STATEMENT_V42_5_4.md canonical/ZERVAN_v42_5_4_CANONICAL_ENTRY.md canonical/Spider/SPIDER_R2_PERSONA_ADMISSION.json canonical/Spider/SPIDER_R2_PERSONA_CONTRACT.md canonical/Spider/SPIDER_R2_FULL_PERSONA_SPECIFICATION.md canonical/Spider/ONE_RUN_SPIDER_PERSONA_INITIALIZATION_R2.txt; do
  mkdir -p "$(dirname "$repo_dir/$relative")"
  cp "$overlay/$relative" "$repo_dir/$relative"
done
mkdir -p "$repo_dir/candidate/SpiderPersonaR2"
cp "$package_dir"/candidate/* "$repo_dir/candidate/SpiderPersonaR2/"
mkdir -p "$repo_dir/candidate/SpiderPersonaR2/source"
cp "$package_dir"/source/* "$repo_dir/candidate/SpiderPersonaR2/source/"
mkdir -p "$repo_dir/candidate/SpiderPersonaR2/verification"
cp "$package_dir"/verification/QUALIFICATION_RECEIPT.md "$repo_dir/candidate/SpiderPersonaR2/verification/"
cp "$package_dir"/verification/PACKAGE_MANIFEST.json "$repo_dir/candidate/SpiderPersonaR2/verification/"

git -C "$repo_dir" status --short
printf '%s\n' 'Approved overlay copied to working tree. No commit, push, publication receipt, runtime activation, or WORK ID issued.'
printf '%s\n' 'Review the complete diff, commit/push under Human Gate, then resolve and verify actual origin/main commit.'
