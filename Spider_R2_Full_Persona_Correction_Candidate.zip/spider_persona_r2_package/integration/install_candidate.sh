#!/usr/bin/env bash
set -euo pipefail

repo_dir=${1:?Provide the local Zervan-Central checkout path}
package_dir=$(cd "$(dirname "${BASH_SOURCE[0]}")/.." && pwd)
expected_head=bde60b3e16c978070d46047847fd00e0d7938af4

test "$(git -C "$repo_dir" rev-parse --show-toplevel)" = "$(cd "$repo_dir" && pwd)"
test "$(git -C "$repo_dir" branch --show-current)" = main
test "$(git -C "$repo_dir" rev-parse HEAD)" = "$expected_head"
test -z "$(git -C "$repo_dir" status --porcelain)"
python3 "$package_dir/verification/validate_package.py" "$package_dir"

target="$repo_dir/candidate/SpiderPersonaR2"
test ! -e "$target"
mkdir -p "$target"
cp "$package_dir"/candidate/* "$target/"
mkdir -p "$target/source" "$target/verification"
cp "$package_dir"/source/* "$target/source/"
cp "$package_dir"/verification/QUALIFICATION_RECEIPT.md "$target/verification/"
cp "$package_dir"/verification/PACKAGE_MANIFEST.json "$target/verification/"

git -C "$repo_dir" status --short
printf '%s\n' 'Spider R2 persona candidate copied. Active VERSION and canon unchanged. No commit or push performed.'
