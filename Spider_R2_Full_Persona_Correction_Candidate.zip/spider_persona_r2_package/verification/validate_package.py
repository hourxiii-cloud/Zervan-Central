#!/usr/bin/env python3
"""Check candidate content identity, coherence and overlay before transfer."""
import hashlib
import json
import sys
from pathlib import Path

root = Path(sys.argv[1]).resolve() if len(sys.argv) > 1 else Path(__file__).resolve().parents[1]
sha = lambda p: hashlib.sha256(p.read_bytes()).hexdigest()
manifest = json.loads((root / 'verification/PACKAGE_MANIFEST.json').read_text())
for item in manifest['payloads']:
    path = root / item['path']
    assert path.is_file(), item['path']
    assert len(path.read_bytes()) == item['size_bytes'], item['path']
    assert sha(path) == item['sha256'], item['path']

admission = json.loads((root / 'candidate/SPIDER_R2_PERSONA_ADMISSION_CANDIDATE.json').read_text())
assert admission['persona'] == 'SPIDER' and admission['canonical'] is False
for item in admission['payloads']:
    assert sha(root / item['path']) == item['sha256'], item['path']

spec = (root / 'candidate/SPIDER_R2_FULL_PERSONA_SPECIFICATION.md').read_text()
init = (root / 'candidate/ONE_RUN_SPIDER_PERSONA_INITIALIZATION_R2.txt').read_text()
assert spec.count('## Appendix A') == 1
assert spec.split('```text\n', 1)[1].split('\n```', 1)[0] + '\n' == init
assert all(f'## {i}.' in spec for i in range(1, 20))
assert 'Spider is a **native, named, bounded analytical persona**' in spec
assert 'not an identity-bearing persona' not in spec[:spec.index('## 19.')].lower()
assert 'Spider performs **one complete bounded analytical run** only when the user explicitly supplies or requests a specific question and identified input set' in spec
assert 'PRODUCER=CHAT' in (root / 'candidate/SPIDER_R2_PERSONA_CONTRACT.md').read_text()
assert sha(root / 'source/CR_SPIDER_R1_CLEAN_FULL_FROZEN.md') == '41c238b63ca91a01b9d526fe55ac45617dbc172c8e17e1def35923ef696c0ac0'
assert sha(root / 'source/ONE_RUN_SPIDER_INITIALIZATION_R1.txt') == '1dc3e4c3d578211ba6dac52d9bb950f18f2153c921572f3ed1ab33a7e07f723f'

overlay = root / 'integration/canonical_overlay'
v = json.loads((overlay / 'VERSION.json').read_text())
assert v['version'] == 'vTemporal.42.5.4' and v['parent_canonical_commit'] == 'bde60b3e16c978070d46047847fd00e0d7938af4'
assert v['initiation_call'] == 'call/INITIATION_STATEMENT_V42_5_4.md'
assert v['canonical_entry'] == 'canonical/ZERVAN_v42_5_4_CANONICAL_ENTRY.md'
for name in ('SPIDER_R2_PERSONA_CONTRACT.md','SPIDER_R2_FULL_PERSONA_SPECIFICATION.md','ONE_RUN_SPIDER_PERSONA_INITIALIZATION_R2.txt'):
    assert (overlay / 'canonical/Spider' / name).read_bytes() == (root / 'candidate' / name).read_bytes()
release_admission = json.loads((overlay / 'canonical/Spider/SPIDER_R2_PERSONA_ADMISSION.json').read_text())
assert release_admission['canonical'] is True and release_admission['publication'] == 'PENDING verification receipt'
for item in release_admission['payloads']:
    assert sha(overlay / item['path']) == item['sha256']

print(f'PASS: {len(manifest["payloads"])} package hashes, persona method, source preservation, initializer equality, and overlay integrity')
print('Standing: candidate specification only; no runtime validation or canonical publication asserted')
