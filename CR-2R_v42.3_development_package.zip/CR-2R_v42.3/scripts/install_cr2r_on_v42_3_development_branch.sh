#!/usr/bin/env bash
set -euo pipefail

BRANCH="development/v42.3"
PKG_ROOT="$(cd "$(dirname "${BASH_SOURCE[0]}")/.." && pwd)"
SOURCE="$PKG_ROOT/candidate/change_requests/CR-2R_HARMONY_TEMPORAL_MOBIUS_ROOT_CAUSE_QUALIFICATION.md"
DEST="candidate/change_requests/CR-2R_HARMONY_TEMPORAL_MOBIUS_ROOT_CAUSE_QUALIFICATION.md"

git rev-parse --is-inside-work-tree >/dev/null 2>&1 || { echo "ABORT: run from Zervan-Central."; exit 1; }

if [[ -n "$(git status --porcelain)" ]]; then
  echo "ABORT: working tree is not clean."
  git status --short
  exit 1
fi

git fetch origin main
git switch main
git pull --ff-only origin main

if git show-ref --verify --quiet "refs/heads/$BRANCH"; then
  git switch "$BRANCH"
else
  git switch -c "$BRANCH" origin/main
fi

mkdir -p "$(dirname "$DEST")"
cp "$SOURCE" "$DEST"

echo
echo "=== CR-2R STAGED ON $BRANCH ==="
git status --short
echo
echo "No commit performed."
echo "No canonical promotion performed."
