# CR-2R — v42.3 Development Branch Package

This package stages CR-2R as an independent v42.3 development object.

Target branch: `development/v42.3`

The installer:
- requires a clean working tree;
- fetches current `origin/main`;
- fast-forwards local `main`;
- creates `development/v42.3` from current `origin/main` if it does not exist;
- otherwise switches to the existing local branch;
- copies CR-2R into `candidate/change_requests/`;
- performs no commit, merge, canonical promotion, or tag.

Run from the root of Zervan-Central:

```bash
bash /path/to/CR-2R_v42.3/scripts/install_cr2r_on_v42_3_development_branch.sh
```

CR-2R remains COMPLETE — PASS / QUALIFIED FOR CANONICAL COMPOSITION REVIEW / Canonical NO / Promotion NONE / Authority NONE / Human Gate ACTIVE.
