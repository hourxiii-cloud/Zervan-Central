# v42.1.1 Canonical Validator Transition Receipt

Target: **vTemporal.42.1.1**  
Base canonical Git `main`: `8534421c35f5b52e261d4e63d6d806e12f9f1e83`  
Authority: **NONE**  
Human Gate: **ACTIVE**  
No Compression Out: **ACTIVE**

## Validator object

`Zervan_v42_1_1_ROOT_OVERLAY.zip`

Canonicalization rule: **hash exact artifact bytes; no normalization**

SHA-256:

`21cf4b951721c3ef8935c879496add98ae801b21e0c7ec3dcdfe0c20e0e47259`

SHA-512:

`6afece609499659896025e755d6fe21136566269871fe5c262deb720f2deb14d67d3a2d6bbbb701116c1da280e848ca53bc1dbd9e9097b5849dc040a585d6ba8`

## Transition

The v42.1.1 canonical integration changes the governed canonical state. The validator therefore moves with the changed object.

Changed object → compute new hash → record transition → preserve prior standing.

This receipt does not treat the hash as truth, correctness, compliance, or authority.

The repository is not the laboratory. This package carries qualified integration state and the validator transition needed to deploy it.

## Deployment boundary

The contents of `repo_overlay/` are repository-root paths. They must be copied to repository root; do not commit this ZIP as an inert repository artifact in place of applying its contents.

After deployment, resolve the resulting exact Git `main` commit and close any promotion-commit fields that explicitly require the post-deployment commit identity.
