# Codespaces Integration Instructions

## Package purpose
This package carries one completed, qualified, staged, CLEAN FULL FROZEN Change Request (CR):

**Qualified Relational Continuity Through Disposable Analytical Space**

It is a candidate for integration into the externally authoritative Zervan repository. The package itself does **not** claim canonical standing and performs no repository mutation.

## Required posture before integration
- Resolve current repository `main` and current canonical version from the repository itself.
- Do not infer canonical state from this package or conversation history.
- Preserve Authority NONE, Human Gate ACTIVE, and No Compression Out unless the authoritative repository explicitly establishes otherwise.
- Do not mutate the five source frozen objects while integrating this CR.
- Do not silently resolve any item listed under the CR's preserved unresolved surface.

## Suggested integration sequence
1. Inspect `MANIFEST.sha256` and verify package files before use.
2. Read `CR_QUALIFIED_RELATIONAL_CONTINUITY.md` in full.
3. Compare the CR against the current external canonical baseline.
4. Validate that no newer canonical object conflicts with the CR's dependencies or preserved distinctions.
5. If composition remains valid, create repository-native CR/staging artifacts according to the current canonical repository conventions.
6. Run the repository's applicable validation/test process.
7. Produce an integration receipt identifying repository branch, pre-integration HEAD, post-integration HEAD, files changed, validation result, and canonical-promotion decision.
8. Promote to canon only through the repository's currently authorized canonical-promotion mechanism.

## Hard integration boundaries
- CLEAN FULL FROZEN source objects are inputs, not rewrite targets.
- `ML SMOOTHING ≠ HYBRID TRANSITION SMOOTHING` remains preserved unless independently qualified.
- CONTROL must not acquire analytical authority.
- CONTROL → HUMAN GATE remains prohibited.
- Goblin Signal must not become command or CONTROL.
- WildFlower must not become finding authority or an always-on `expand everything` operation.
- Successive Clean Rooms must not manufacture independence by cardinality.
- No next inquiry may be inferred where none was established.
- Historical retrieval does not itself restore current standing.

## Expected final repository state
Only after external validation and explicit repository-native promotion may the integrated object be represented as canonical. Until then:

**CANONICAL FALSE.**
