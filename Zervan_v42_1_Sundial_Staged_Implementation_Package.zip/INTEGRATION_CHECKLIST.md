# SUNDIAL — INTEGRATION CHECKLIST

- [ ] Preserve staged lineage.
- [ ] Preserve A → B → X geometry.
- [ ] Require independent standing for X.
- [ ] Preserve object / analysis / Zervan evidence classes.
- [ ] Bind Möbius internal↔external movement without object reconstruction.
- [ ] Preserve Zero Trust analytical standing.
- [ ] Preserve No Footprints.
- [ ] Preserve contemporaneous / replay / retrospective distinctions.
- [ ] Bind AnimalKingdom pressure to qualified need.
- [ ] Preserve Y as returned evidence rather than rewritten prior state.
- [ ] Preserve Human Gate authority.
- [ ] Keep testing outside Git.
- [ ] Do not infer canonical promotion from package presence.
