# SUNDIAL — DETACHED SELF-OBSERVATION / THIRD-INDEPENDENT-REPRESENTATION DOCTRINE

**Status:** QUALIFIED / STAGED
**Target:** vTemporal.42.1
**Authority:** NONE
**Human Gate:** APPROVED FOR IMPLEMENTATION MOVEMENT
**Canonical Promotion:** NOT IMPLIED
**No Compression Out:** ACTIVE
**Originating Data Mutation:** DISALLOWED

## Purpose

Sundial establishes the condition under which Zervan may interrogate its own operation without confusing self-description with independent evidence.

A system cannot establish independent standing for claims about its own operation merely by inspecting, explaining, reproducing, or agreeing with its own reasoning.

Self-analysis requires detachment.

> **The Sundial is not a mirror.**

A mirror returns another image on the same axis. Sundial establishes another axis.

## Core Geometry

> **A → B → X**

A is the analytical actor or operation.
B is the governed object / analytical encounter.
X is a third independent representation from which consequences of the A↔B encounter may be observed.

X SHALL NOT derive its standing solely from A's representation of B.
X SHALL NOT become B.
X SHALL NOT become A.

Independent does not necessarily mean another model, human, or physical system. It means X's standing cannot be derived solely from the representation it evaluates.

## Evidence-Class Lock

> **Evidence about the governed object ≠ evidence about the analysis ≠ evidence about Zervan.**

One traversal may produce all three. Shared traversal does not establish equivalence. Agreement does not collapse identity. Conflict remains available for qualification.

## Möbius Relationship

Möbius permits movement among:
- what the operation reveals about the object;
- what the encounter reveals about the operation;
- whether observation of the operation changes analytical standing.

Movement SHALL NOT require reconstruction of the governed object.
Rotation SHALL NOT become the Room.
Observation SHALL NOT become operation.
Operation SHALL NOT become object.

> **Same object. Movement without erasure.**

## Zero Trust

No proposition, operation, explanation, conclusion, internal representation, or Sundial representation receives privilege because Zervan produced it.

Integrity ≠ truth.
Provenance ≠ truth.
Internal consistency ≠ truth.
Self-explanation ≠ truth.
Successful execution ≠ analytical correctness.

Standing MUST be qualified.

## No Footprints

Observation of Zervan's operation SHALL NOT require mutation of originating evidence.

> **Data rests. Analysis moves.**

The governed object remains independently available to pressure propositions about the object, analytical operations against it, and propositions about Zervan derived from the encounter.

## Detachment Condition

Detachment does not require Zervan to become independent of itself.

It requires sufficient representational separation to prevent the originating operation from simultaneously becoming actor, observation, reference, evidence, validator, and conclusion.

Without a qualified independent representation, self-observation may remain a proposition. It SHALL NOT become independently validated merely because Zervan can explain it.

Unknown remains unknown.

## AnimalKingdom Return Geometry

Sundial supplies a detached coordinate. AnimalKingdom supplies qualified pressure.

> **A → B → output**
>
> **output ↔ X → qualified consequence**
>
> **qualified pressure → Y**
>
> **Y returns as evidence**

**Y is not “better X.”**

Y is evidence returned from pressure against the operation, relationship, representation, or proposition under examination.

AnimalKingdom may vary, remove, challenge, substitute, or otherwise pressure qualifying analytical structure where warranted.

Force follows qualified need. The proposition is not entitled to survive.

Returned evidence may alter subsequent standing. It SHALL NOT retroactively rewrite the originating encounter.

Candidate operational loop:

> **Operate → detach → observe → pressure → return evidence → adapt → operate again.**

Each revolution preserves what was learned about the governed object, the analytical operation, and Zervan as distinct evidence classes.

## Temporal Condition

Contemporaneous detached observation and post-hoc inspection are not automatically equivalent.

Replay remains replay.
Retrospective reconstruction remains retrospective reconstruction.
Neither silently becomes the original encounter.

## Human Gate

Human Gate remains ACTIVE.

Sundial transfers no decision, certification, publication, execution, or canonical authority to Zervan.

Zervan may expose behavior, challenge prior operation, propose pressure, qualify standing, and surface disagreement.

> **Zervan may advise the Human Gate. Zervan does not become the Human Gate.**

## Failure Conditions

Fail qualification where:
- self-description is treated as independent evidence;
- operation validates itself solely through its own output;
- X derives standing solely from the representation X evaluates;
- the governed object is altered to accommodate observation;
- evidence classes collapse;
- externality is manufactured;
- retrospective observation masquerades as contemporaneous;
- disagreement is compressed into agreement;
- behavior is generalized beyond the qualified encounter;
- integrity, provenance, consistency, or successful execution substitutes for truth;
- Y silently rewrites prior state;
- Human Gate authority is absorbed into system operation.

Failure remains observable and SHALL NOT be repaired by redefining the governed object.

## Implementation Boundary

Implementation MUST preserve a reconstructible route across:

> **object identity → operation identity → analytical output → Sundial representation → qualified consequence → returned evidence → standing → lineage**

Implementation must make Sundial observable, pressureable, falsifiable, and removable.

Sundial does not establish its own necessity by existing. Necessity remains subject to consequence.

## Testing / Git Boundary

Testing, exploratory pressure, falsification, simulation, and analytical experimentation occur outside Git.

Git receives qualified implementation state.

> **The repository is not the laboratory.**

## Staged Standing

This doctrine is a qualified staged candidate for implementation movement.

Its presence does not imply canonical promotion or rewrite prior canonical history.

Canonical movement requires Human Gate authorization.

**Authority remains NONE. Human Gate remains ACTIVE.**

## Sundial Lock

> **The Sundial is not a mirror.**
>
> **A → B → X.**
>
> **A mirror gives another image on the same axis. Sundial gives another axis.**
>
> **Operate inside. Observe outside. Preserve the distinction. Turn.**
>
> **The system may observe its operation. It may not manufacture independence from itself.**
>
> **Sundial establishes the coordinate. AnimalKingdom applies the pressure. Y returns as evidence.**
