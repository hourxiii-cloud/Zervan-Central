# CR-2R IMPLEMENTATION BOUNDARY

Purpose: carry the qualified CR-2R review into repository implementation work without silently promoting it.

## Required implementation behavior

Implementation SHALL preserve:
1. Relationship identity across temporal coordinates where identity legitimately persists.
2. O_t and Q_t independently at every relevant coordinate.
3. Historical qualification Q_ti independently from current qualification concerning that historical coordinate, Q_current(ti).
4. Lineage sufficient to demonstrate movement among preserved coordinates.
5. Existing Möbius invariant: movement without reconstruction or retrospective overwrite.
6. Existing Harmony relational standing and temporal comparison boundaries.
7. Existing Sundial independence boundary.
8. Existing AnimalKingdom pressure boundary.
9. Y as returned evidence without retrospective rewrite.
10. Authority NONE and Human Gate ACTIVE.

## Implementation SHALL NOT

- make the candidate canonical merely by implementing it;
- change VERSION or promotion state absent separate Human Gate authorization;
- rewrite originating evidence;
- rewrite earlier analytical state using later evidence;
- treat chronology, persistence, recurrence, contraction, expansion, recovery, or missing expected effects as causal proof;
- treat missing observation as qualified absence without sufficient observation standing;
- substitute reconstructed history for preserved Möbius movement;
- collapse ΔO and ΔQ;
- collapse Q_ti and Q_current(ti);
- make Möbius a causal, independence, pressure, decision, or truth authority.

## Integration expectation

Repository implementation should expose the minimum complete surfaces necessary for:
- preserved temporal relationship state;
- traversal among preserved coordinates;
- historical/current-standing separation;
- lineage/integrity verification;
- fail-closed enforcement of the boundaries above.

Exact repository files and version consequence SHALL be resolved against current Git state during implementation review. This package does not preselect a version number or canonical promotion outcome.

Testing remains outside Git. Repository is not the laboratory.
