# STAGED — Harmony Temporal Contraction / Restriction

Status: STAGED  
Authority: NONE  
Human Gate: ACTIVE  
Canonical: NO  
Promotion: NONE  
No Compression Out: ACTIVE

## Temporal condition

Harmony may inspect not only relationships within a state, but the same qualified relationship across temporal coordinates:

`(A ↔ B)_t1 ↔ (A ↔ B)_t2`

The difference between those conditions is itself data.

## Critical distinction

Contraction describes change in the observed support geometry of the relationship: `O_t1 → O_t2`.

A relationship previously observable across some territory is subsequently observable across less territory.

Restriction describes change in the justified standing of the analytical claim: `Q_t1 → Q_t2`.

Additional evidence narrows what the analysis is entitled to claim, whether or not the observed phenomenon itself changed.

Therefore: **Contraction is not restriction.**

A relationship may contract without its qualified interpretation becoming more restricted. A claim may become restricted while the observed relationship remains unchanged.

The converse conditions remain distinguishable:

- Expansion — observed support geometry increases through time.
- Relaxation — available evidence justifies broadening previously restricted analytical standing.

Thus:

`Observed Geometry: Expansion ↔ Contraction`

`Qualified Standing: Relaxation ↔ Restriction`

These dimensions may move independently.

A phenomenon may expand while its analytical standing restricts. A phenomenon may contract while improved evidence permits greater specificity or confidence concerning what remains.

## Required preservation

For temporal comparison, preserve independently: `O_t1, Q_t1, O_t2, Q_t2`, such that `ΔO = O_t2-O_t1` and `ΔQ = Q_t2-Q_t1`.

Neither delta may silently substitute for the other.

Later evidence SHALL NOT rewrite the earlier observational or qualification state merely because subsequent information changes current standing.

## Harmony condition

Harmony may therefore distinguish change in the governed phenomenon from change in what the analysis is entitled to say about the governed phenomenon.

Time supplies a new analytical coordinate; it does not grant later state retrospective authority over earlier state.

## Candidate formulation

**Harmony preserves the right of a relationship to change without allowing its previous state to disappear.**

## Boundary

Temporal difference is data, not inherently error, improvement, degradation, causation, or explanation.

Observed contraction does not establish analytical restriction. Analytical restriction does not establish observed contraction. Expansion does not establish strengthening. Relaxation does not establish truth.

A temporal delta establishes only the qualified difference supported between preserved coordinates.

STAGED. Not canonical. No promotion implied.
