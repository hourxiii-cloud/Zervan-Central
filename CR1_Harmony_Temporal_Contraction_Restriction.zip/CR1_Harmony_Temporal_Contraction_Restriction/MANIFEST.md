# CR-1 Integration Package Manifest

Package: CR1_Harmony_Temporal_Contraction_Restriction
Purpose: portable upload/integration package for CR-1 canonical review state.

Baseline:
- Repository: hourxiii-cloud/Zervan-Central
- Branch: main
- Version: vTemporal.42.1.1
- HEAD: a802f2a971dc7f96065a169f64a02430baf0f8af

Contents:
1. STAGED_HARMONY_TEMPORAL_CONTRACTION_RESTRICTION.md — preserved staged source object.
2. CR1_HARMONY_TEMPORAL_CONTRACTION_RESTRICTION.md — completed CR-1 review and disposition.
3. MANIFEST.md — package identity and boundaries.
4. SHA256SUMS.txt — package-file integrity hashes.

Standing:
- CR-1: COMPLETE — PASS
- Candidate: QUALIFIED FOR CANONICAL COMPOSITION REVIEW
- Canonical: NO
- Promotion: NONE
- Git movement: NONE
- Authority: NONE
- Human Gate: ACTIVE
- No Compression Out: ACTIVE

Integration boundary:
This package does not authorize promotion or Git movement. It preserves the staged object and CR-1 result for subsequent CR-2 / composition review and Human Gate-controlled integration.
