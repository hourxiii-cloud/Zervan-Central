from relational_maneuver import (
    AuditView, EarnedRelationship, Inquiry, Position, PressureProposal,
    QualifiedDelta, RelationalManeuverEngine, RelationalState, Standing,
    new_opportunity,
)


def base_state():
    return RelationalState(
        state_id="s0",
        object_ref="object",
        field_ref="field-0",
        dimensions={"x": 1, "y": 2, "standing": "independent"},
    )


def test_sparse_delta_does_not_move_unrelated_dimension():
    s = base_state()
    d = QualifiedDelta("d1", "x", observed=3, qualified=3)
    r = RelationalManeuverEngine().transition(s, d)
    assert r.next_state.dimensions["x"] == 3
    assert r.next_state.dimensions["y"] == 2
    assert "y" in r.held_dimensions


def test_relationship_does_not_infer_target_value():
    s = base_state()
    d = QualifiedDelta("d1", "x", observed=3, qualified=3)
    e = EarnedRelationship("e1", "x", "y", Standing.QUALIFIED)
    r = RelationalManeuverEngine().transition(s, d, [e])
    assert r.next_state.dimensions["y"] == 2
    assert "e1" not in r.used_relationships


def test_earned_relationship_can_propagate_explicit_value():
    s = base_state()
    d = QualifiedDelta("d1", "x", observed=3, qualified=3)
    e = EarnedRelationship("e1", "x", "y", Standing.QUALIFIED)
    r = RelationalManeuverEngine().transition(s, d, [e], {"y": 9})
    assert r.next_state.dimensions["y"] == 9
    assert r.used_relationships == ("e1",)


def test_expected_is_not_qualified():
    s = base_state()
    d = QualifiedDelta("d1", "x", expected=3)
    try:
        RelationalManeuverEngine().transition(s, d)
        assert False
    except ValueError:
        pass


def test_new_opportunity_has_new_identity():
    q = Inquiry("q", "object", "question", Standing.QUALIFIED)
    p = Position("p", "sniper", "field-0")
    a = new_opportunity(q, p, "field-0", "t1", Standing.QUALIFIED)
    b = new_opportunity(q, p, "field-0", "t2", Standing.QUALIFIED)
    assert a.opportunity_id != b.opportunity_id


def test_pressure_cannot_determine_conclusion():
    try:
        PressureProposal("c2", "need", "is c2 true?", Standing.QUALIFIED, True)
        assert False
    except ValueError:
        pass


def test_audit_has_no_execution_surface():
    audit = AuditView()
    forbidden = {"repair", "retry", "reroute", "mutate", "execute", "promote", "authorize"}
    assert not any(hasattr(audit, name) for name in forbidden)
