"""vTemporal.42.3 candidate relational maneuver primitives.

Candidate implementation only.
Authority: NONE
Human Gate: ACTIVE
Canonical: FALSE
Validation: NOT YET PERFORMED
"""
from __future__ import annotations

from dataclasses import dataclass, field, replace
from enum import Enum
from typing import Any, Callable, Mapping, Optional, Sequence, Tuple
from uuid import uuid4


class Standing(str, Enum):
    UNKNOWN = "UNKNOWN"
    OBSERVED = "OBSERVED"
    QUALIFIED = "QUALIFIED"
    DISQUALIFIED = "DISQUALIFIED"


class Disposition(str, Enum):
    HOLD = "HOLD"
    OBSERVE = "OBSERVE"
    REPORT = "REPORT"
    CONSOLIDATE = "CONSOLIDATE"
    REENGAGE = "RE-ENGAGE"
    REPOSITION = "REPOSITION"
    PRESSURE = "PRESSURE"
    TRAVERSE = "TRAVERSE"
    RENEST = "RE-NEST"
    CLOSE = "CLOSE"
    OTHER = "OTHER"


@dataclass(frozen=True)
class EvidenceRef:
    ref: str
    standing: Standing
    provenance: str


@dataclass(frozen=True)
class Position:
    position_id: str
    capability: str
    field_ref: str
    perspective: Optional[str] = None
    standing: Standing = Standing.UNKNOWN


@dataclass(frozen=True)
class Inquiry:
    inquiry_id: str
    object_ref: str
    question: str
    standing: Standing
    active: bool = True
    closed: bool = False


@dataclass(frozen=True)
class Opportunity:
    opportunity_id: str
    inquiry_id: str
    position_id: str
    field_ref: str
    time_ref: str
    standing: Standing


@dataclass(frozen=True)
class BoundaryEvent:
    internal_event_ref: Optional[str] = None
    crossing_ref: Optional[str] = None
    external_consequence_ref: Optional[str] = None
    internal_time: Optional[str] = None
    crossing_time: Optional[str] = None
    external_time: Optional[str] = None


@dataclass(frozen=True)
class QualifiedDelta:
    delta_id: str
    source_dimension: str
    expected: Any = None
    observed: Any = None
    qualified: Any = None
    evidence: Tuple[EvidenceRef, ...] = ()
    time_ref: Optional[str] = None

    @property
    def is_qualified(self) -> bool:
        return self.qualified is not None


Predicate = Callable[[QualifiedDelta, "RelationalState"], bool]


@dataclass(frozen=True)
class EarnedRelationship:
    relationship_id: str
    source_dimension: str
    target_dimension: str
    standing: Standing
    evidence: Tuple[EvidenceRef, ...] = ()
    predicate: Optional[Predicate] = None

    def permits(self, delta: QualifiedDelta, state: "RelationalState") -> bool:
        if self.standing is not Standing.QUALIFIED:
            return False
        if delta.source_dimension != self.source_dimension:
            return False
        return True if self.predicate is None else bool(self.predicate(delta, state))


@dataclass(frozen=True)
class Return:
    return_id: str
    engagement_ref: str
    opportunity_id: str
    field_before: str
    telemetry: Mapping[str, Any]
    evidence: Tuple[EvidenceRef, ...] = ()
    exposure: Mapping[str, Any] = field(default_factory=dict)


@dataclass(frozen=True)
class Trace:
    object_ref: str
    inquiry_id: Optional[str] = None
    position_id: Optional[str] = None
    engagement_ref: Optional[str] = None
    return_id: Optional[str] = None
    relationship_ids: Tuple[str, ...] = ()
    delta_ids: Tuple[str, ...] = ()


@dataclass(frozen=True)
class RelationalState:
    state_id: str
    object_ref: str
    field_ref: str
    dimensions: Mapping[str, Any]
    positions: Mapping[str, Position] = field(default_factory=dict)
    inquiries: Mapping[str, Inquiry] = field(default_factory=dict)
    opportunities: Mapping[str, Opportunity] = field(default_factory=dict)
    evidence: Tuple[EvidenceRef, ...] = ()
    trace: Tuple[Trace, ...] = ()

    def value(self, dimension: str) -> Any:
        return self.dimensions.get(dimension)


@dataclass(frozen=True)
class TransitionResult:
    prior_state_id: str
    next_state: RelationalState
    applied_dimensions: Tuple[str, ...]
    held_dimensions: Tuple[str, ...]
    used_relationships: Tuple[str, ...]


class RelationalManeuverEngine:
    """Sparse qualified movement. No relationship => no manufactured propagation."""

    def transition(
        self,
        state: RelationalState,
        delta: QualifiedDelta,
        relationships: Sequence[EarnedRelationship] = (),
        target_values: Optional[Mapping[str, Any]] = None,
    ) -> TransitionResult:
        if not delta.is_qualified:
            raise ValueError("Delta is not qualified.")

        target_values = dict(target_values or {})
        dimensions = dict(state.dimensions)
        applied = []
        used = []

        # The source dimension may move because the qualified delta directly addresses it.
        dimensions[delta.source_dimension] = delta.qualified
        applied.append(delta.source_dimension)

        for rel in relationships:
            if rel.permits(delta, state):
                target = rel.target_dimension
                if target not in target_values:
                    # Never infer a consequential target value.
                    continue
                dimensions[target] = target_values[target]
                applied.append(target)
                used.append(rel.relationship_id)

        all_dims = set(state.dimensions) | set(dimensions)
        held = sorted(all_dims - set(applied))

        trace = state.trace + (
            Trace(
                object_ref=state.object_ref,
                relationship_ids=tuple(used),
                delta_ids=(delta.delta_id,),
            ),
        )
        next_state = replace(
            state,
            state_id=str(uuid4()),
            dimensions=dimensions,
            trace=trace,
        )
        return TransitionResult(
            prior_state_id=state.state_id,
            next_state=next_state,
            applied_dimensions=tuple(applied),
            held_dimensions=tuple(held),
            used_relationships=tuple(used),
        )


class AuditView:
    """Observability without execution authority."""

    def observe(self, value: Any) -> Any:
        return value

    def attribute(self, value: Any, provenance: str) -> Mapping[str, Any]:
        return {"value": value, "provenance": provenance}

    def assess(self, attributed: Mapping[str, Any], consequence: Any = None) -> Mapping[str, Any]:
        return {"attributed": dict(attributed), "consequence": consequence}

    def report(self, assessment: Mapping[str, Any]) -> Mapping[str, Any]:
        return dict(assessment)


@dataclass(frozen=True)
class PressureProposal:
    condition_ref: str
    qualified_need_ref: str
    bounded_question: str
    standing: Standing
    determines_conclusion: bool = False

    def __post_init__(self) -> None:
        if self.determines_conclusion:
            raise ValueError("AnimalKingdom pressure cannot determine conclusion.")


@dataclass(frozen=True)
class TOCView:
    field_ref: str
    current_state_id: str

    def revise(self, transition: TransitionResult) -> "TOCView":
        return TOCView(
            field_ref=transition.next_state.field_ref,
            current_state_id=transition.next_state.state_id,
        )


def new_opportunity(
    inquiry: Inquiry,
    position: Position,
    field_ref: str,
    time_ref: str,
    standing: Standing,
) -> Opportunity:
    # Every opportunity gets a new identity; prior opportunity standing is not inherited.
    return Opportunity(
        opportunity_id=str(uuid4()),
        inquiry_id=inquiry.inquiry_id,
        position_id=position.position_id,
        field_ref=field_ref,
        time_ref=time_ref,
        standing=standing,
    )
