# vTemporal.42.3.0 — Qualified Relational Maneuver / Consequential State Economy
## Candidate Implementation Contract

Status: IMPLEMENTATION CANDIDATE
Canonical: FALSE
Promotion: NONE
Authority: NONE
Human Gate: ACTIVE
No Compression Out: REQUIRED / ACTIVE
Originating Data Mutation: DISALLOWED
External Runtime / Action: DISABLED
System Population: DISALLOWED unless independently qualified
CR-1: PRESERVED / UNCHANGED
CR-2: PRESERVED / UNCHANGED
CR-03: CLEAN FROZEN / IMPLEMENTATION BASIS
Validation: NOT YET PERFORMED

This implementation realizes CR-03 without treating implementation as validation or promotion.

## Governing economy

PRESERVE RICHLY
→ COLLAPSE LEGITIMATELY
→ OPERATE SPARSELY
→ RECONSTRUCT CONSEQUENTIALLY

EXPENSIVE INTEGRITY → CHEAP MANEUVER.

The state remains whole. The delta tells us where the work is.

## Required primitives

The implementation provides a minimum sufficient primitive set rather than one implementation object per developmental object:

1. `RelationalState` — preserved qualified current state.
2. `QualifiedDelta` — attributable movement with expected / observed / qualified separation.
3. `EarnedRelationship` — explicit propagation permission between dimensions.
4. `Position` — capability position independent of perspective, standing, inquiry, and authority.
5. `BoundaryEvent` — internal event / boundary crossing / external consequence kept separable.
6. `Inquiry` — inquiry identity independent of position and pressure.
7. `Opportunity` — position + field + time qualified opportunity identity.
8. `Return` — consequential return distinct from disposition.
9. `Standing` — independently preserved standing; telemetry does not transfer it.
10. `Trace` — reconstructibility route back through delta, relationship, return, engagement, position, inquiry, object.
11. `RelationalManeuverEngine` — sparse propagation and current-state transition.
12. `AuditView` — observe / attribute / assess / report only.
13. `PressureProposal` — bounded AnimalKingdom pressure proposal without conclusion authority.
14. `TOCView` — current-field representation without position assignment or shot authorization.

## State movement

A delta does not propagate merely because it exists.

`ΔX -> ΔY` is permitted only when an explicit, qualified `EarnedRelationship(X,Y)` is supplied and its predicate is satisfied.

No relationship means no manufactured propagation.

Nonpropagation does not mean immutability.

## Consequential compression

The implementation may collapse common computational relationships while preserving consequential distinctions. It SHALL NOT reconstruct missing consequential information by inference.

`reconstructible != inferable`

Losslessness is purpose bounded.

## Position and inquiry

`position != perspective`
`position != inquiry`
`release position != release inquiry`
`preserve inquiry != mandatory pressure`
`inquiry active != engagement active`
`time passage != pressure trigger`
`continuity != refusal to close`

## Internal / external

`internal != external`

Internal event, boundary crossing, and external consequence remain distinct records. Unknown remains unknown. No missing crossing, time, consequence, or causation is synthesized.

## Audit

Audit can see across the seam. Audit does not own the seam.

Audit has no repair, retry, reroute, mutation, execution, promotion, or authorization method.

## AnimalKingdom pressure

Pressure interrogates a required condition. It does not determine Audit disposition and does not recursively authorize more pressure.

## Opportunity / return / TOC

The first engagement consumes its opportunity, not necessarily its position.

A second shot requires a second independently qualified opportunity.

Return is not disposition.

TOC may represent current field after qualified delta. TOC does not assign capability position, authorize engagement, or manufacture opportunity.

## Hallway / re-nest

Movement preserves the interval:

NEST_A → HALLWAY → NEST_B

Exit is not entry. Arrival is not standing. Re-nest is not restore.

## Preservation boundary

PRESERVATION != RESIDENCY != ATTENTION != TRANSPORT != MANEUVER LOAD

The governed object remains preserved while a capability carries only minimum sufficient maneuver state.

## Authority boundary

Authority remains NONE.
Human Gate remains ACTIVE.
Implementation does not promote itself.
