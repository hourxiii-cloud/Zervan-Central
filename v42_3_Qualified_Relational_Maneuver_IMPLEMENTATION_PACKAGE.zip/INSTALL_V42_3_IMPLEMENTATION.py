#!/usr/bin/env python3
from pathlib import Path
import shutil, subprocess, sys

EXPECTED_BRANCH = "development/v42.3"
SRC = Path(__file__).resolve().parent / "payload"
DEST = Path("development") / "v42_3" / "implementation"

def git(*args):
    p = subprocess.run(["git", *args], text=True, stdout=subprocess.PIPE, stderr=subprocess.PIPE)
    if p.returncode:
        raise RuntimeError(p.stderr.strip() or p.stdout.strip())
    return p.stdout.strip()

branch = git("branch", "--show-current")
if branch != EXPECTED_BRANCH:
    raise SystemExit(f"ABORT: expected branch {EXPECTED_BRANCH!r}; found {branch!r}")

if not SRC.exists():
    raise SystemExit("ABORT: payload directory missing.")

DEST.mkdir(parents=True, exist_ok=True)
for p in SRC.iterdir():
    if p.is_file():
        shutil.copy2(p, DEST / p.name)

print("v42.3 candidate implementation staged at:", DEST)
print("Canonical promotion: NONE")
print("Validation: NOT YET PERFORMED")
print("No commit performed.")
