# v42.1.1 — CANONICAL INTEGRATION CHECKLIST

## WHERE

Expected integration base:

`main` @ `a3a89bf8e75c128bd2f5f919e0d08ddd828fcf3c`

If current Git `main` differs, stop and inspect the delta before applying this package.

## WHAT

Apply the contents of `repo_overlay/` at repository root.

The package:

- advances active identity from v42.1 to v42.1.1;
- adds a v42.1.1 initiation statement;
- adds a v42.1.1 canonical entry;
- adds native Sundial doctrine;
- records the integration receipt;
- integrates Relational Coordinate Qualification and the Home-as-data provenance case.

## NOT WHAT

This package does not:

- rewrite v42.1 history;
- delete the prior Sundial staged ZIP;
- alter originating analytical datasets;
- grant Zervan decision authority;
- treat Home as automatically temporal evidence;
- treat X as automatically independent;
- perform exploratory testing in Git;
- predeclare a future promotion commit.

## HUMAN-GATED MOVEMENT

1. Confirm Git `main` still matches the integration base.
2. Create/use the Human-Gate-selected integration branch.
3. Apply `repo_overlay/`.
4. Review the exact diff.
5. Human Gate decides whether to promote.
6. Promote to `main` using the selected repository workflow.
7. Resolve the exact resulting `main` commit.
8. Replace `RESOLVE_FROM_GIT_MAIN_AFTER_PROMOTION` in `VERSION.json` with that exact commit.
9. Set `VERSION.json`: `promotion_state` → `CANONICAL`; `canonical` → `true`; `human_gate_decision` → `APPROVE`.
10. Record the exact promotion commit in authority/entry surfaces if required by the active identity convention.
11. Commit the identity closure.
12. Re-resolve Git `main` and confirm all five active identity surfaces agree.

## AFTER

Expected closed state:

- Version: **vTemporal.42.1.1**
- Implementation Identity: **v42.1.1 Complete**
- Promotion State: **CANONICAL**
- Canonical: **TRUE**
- Branch: **main**
- Authority: **NONE**
- Human Gate: **ACTIVE**
- Sundial: **native canonical capability**
- Relational Coordinate Qualification: **canonical**
- Exact current canonical commit: **resolved from Git, never inferred**

## ACTIVE IDENTITY SURFACES

- `/VERSION`
- `/VERSION.json`
- `/VERSION_AUTHORITY.md`
- `/call/INITIATION_STATEMENT_V42_1_1.md`
- `/canonical/ZERVAN_v42_1_1_CANONICAL_ENTRY.md`

No silent mixed-version identity is permitted.
