import copy
import importlib.util
import json
from pathlib import Path
import unittest

ROOT = Path(__file__).resolve().parents[1]
spec = importlib.util.spec_from_file_location('gate', ROOT/'tools/validate_null_collapse_v42_5_2.py')
gate = importlib.util.module_from_spec(spec)
spec.loader.exec_module(gate)


def fixture():
    base = json.loads((ROOT/'verification/v42.5.2/WORLD_BOX_COMPOSITION_EXAMPLE.json').read_text())
    w = base['world_development']
    w['events'] = []
    base['null_collapse'] = gate.start(w['origin'])
    return base


def observation(env, oid='o1', content='Accurate datum; proposed cause is unqualified'):
    env['world_development'] = gate.world.append_event(env['world_development'], {
        'id': oid, 'type': 'OBSERVE', 'subject_ref': 'object:inquiry',
        'observation_kind': 'ORDINARY', 'source_ref': 'source',
        'content': content, 'frame_refs': ['frame'], 'contribution_ref': 'contribution'})


def event(env, kind, eid, tick=1, **kwargs):
    return dict(id=eid, type=kind, tick=tick, time_basis='frame', contribution_ref='contribution',
                world_event_count=len(env['world_development']['events']), **kwargs)


def add(env, e):
    env['null_collapse'] = gate.append_event(env['null_collapse'], env['world_development'], e)


def note(env, oid='o1', nid='n1', tick=1, attribution='UNRESOLVED'):
    # New World evidence may legitimately be pending; append only validates the result.
    e = event(env, 'NOTE', nid, tick, observation_id=oid, observation_operation='measurement operation',
              pre_state='UNRESOLVED', post_state='observed after measurement', induced_delta='UNRESOLVED', attribution=attribution)
    add(env, e)


def possibility(pid='p1', dependencies=None):
    return dict(id=pid, content='Candidate A', standing='SUPPORTED', dependencies=dependencies or [])


def prediction(pid='f1', basis='p1', horizon=10):
    return dict(id=pid, content='A expected within qualified horizon', standing='SUPPORTED',
                dependencies=[basis], horizon=horizon, possibility_ids=[basis])


def rotate(env, eid='r1', tick=1, possibilities=None, predictions=None, references=None, **extra):
    return event(env, 'ROTATE', eid, tick, note_ids=['n1'], reference_ids=references or [],
                 qualification_ref='qualification', rationale='Synthetic independently supplied qualification judgment',
                 frame_assessment='Datum retained; causal framing not accepted without qualification',
                 possibilities=possibilities or [], predictions=predictions or [],
                 compute=extra.get('compute','bounded'), force=extra.get('force','none'))


def state(env):
    return gate.replay(env['null_collapse'], env['world_development'])


def ready():
    e = fixture()
    observation(e)
    note(e)
    return e


class CollapseTests(unittest.TestCase):
    def test_T01_null_integrity(self):
        e = fixture()
        self.assertEqual(state(e)['current'], {})
        with self.assertRaises(ValueError):
            add(e, rotate(e, possibilities=[possibility()], predictions=[prediction()]))

    def test_T02_noting_without_relationship(self):
        e = ready()
        self.assertTrue(state(e)['notes'])
        self.assertFalse(state(e)['current'])

    def test_T03_true_datum_false_framing(self):
        e = ready()
        before = copy.deepcopy(e['world_development'])
        add(e, rotate(e))
        self.assertEqual(before, e['world_development'])
        self.assertEqual(state(e)['current'], {})
        del e['null_collapse']['events'][-1]['frame_assessment']
        self.assertTrue(gate.validate(e['null_collapse'], e['world_development']))

    def test_T04_prediction_emitted_when_warrant_recorded(self):
        e = ready()
        add(e, rotate(e, possibilities=[possibility()], predictions=[prediction()]))
        self.assertEqual(state(e)['prediction_state'], 'AVAILABLE')
        self.assertIn('f1', state(e)['current'])

    def test_T05_eventual_correctness_cannot_repair_early_warrant(self):
        e = ready()
        bad = rotate(e, predictions=[prediction()])
        e['null_collapse']['events'].append(bad)
        observation(e, 'outcome', 'A happened')
        self.assertTrue(gate.validate(e['null_collapse'], e['world_development']))

    def test_T06_no_posthoc_prediction(self):
        e = ready()
        with self.assertRaises(ValueError):
            add(e, rotate(e, tick=10, possibilities=[possibility()], predictions=[prediction(horizon=10)]))

    def test_T07_actualization_requires_new_observation(self):
        e = ready()
        add(e, rotate(e, possibilities=[possibility()], predictions=[prediction()]))
        outcome = event(e, 'ACTUALIZE', 'a1', 2, prediction_id='f1', note_id='n1',
                        qualification_ref='qualification', outcome='SUPPORTED', rationale='Observed outcome')
        with self.assertRaises(ValueError):
            add(e, outcome)
        observation(e, 'o2', 'A happened')
        note(e, 'o2', 'n2', 2)
        outcome.update(note_id='n2', world_event_count=2)
        add(e, outcome)
        self.assertEqual(state(e)['history']['f1']['tick'], 1)
        self.assertIn('a1', state(e)['actualizations'])
        self.assertNotIn('f1', state(e)['current'])

    def test_T08_history_and_alternatives_survive(self):
        e = ready()
        add(e, rotate(e, possibilities=[possibility('a'), possibility('b')]))
        before = copy.deepcopy(e['null_collapse'])
        add(e, rotate(e, eid='r2', tick=2))
        self.assertEqual(set(state(e)['current']), {'a','b'})
        self.assertFalse(gate.validate(e['null_collapse'], e['world_development'], before))
        e['null_collapse']['events'][0]['pre_state'] = 'rewritten'
        self.assertTrue(gate.validate(e['null_collapse'], e['world_development'], before))

    def test_T09_QN01_transitive_dependency_radius(self):
        e = ready()
        add(e, rotate(e, possibilities=[possibility('a'), possibility('b', ['a']), possibility('independent')],
                      predictions=[prediction(basis='b')]))
        add(e, event(e,'CHALLENGE','c1',2,note_ids=['n1'],targets=['a'],qualification_ref='qualification',rationale='Basis defective'))
        self.assertEqual(set(state(e)['requalification_required']), {'a','b','f1'})
        self.assertEqual(set(state(e)['current']), {'independent'})
        self.assertEqual(len(state(e)['history']), 4)

    def test_T10_force_compute_independence(self):
        e = ready()
        add(e, rotate(e, possibilities=[possibility()], force='platoon', compute='small reuse'))
        add(e, event(e,'ENGAGE','g1',1,dependencies=['p1'],qualification_ref='qualification',force='platoon',compute='small reuse',rationale='Object warrants force'))
        self.assertEqual(state(e)['engagements']['g1']['force'], 'platoon')

    def test_T11_consequential_change_expires_engagement(self):
        e = ready()
        add(e, rotate(e, possibilities=[possibility()]))
        add(e, event(e,'ENGAGE','g1',1,dependencies=['p1'],qualification_ref='qualification',force='high',compute='bounded',rationale='Qualified'))
        add(e, event(e,'CHALLENGE','c1',2,note_ids=['n1'],targets=['p1'],qualification_ref='qualification',rationale='Consequential object change'))
        self.assertEqual(state(e)['engagements']['g1']['state'], 'EXPIRED')
        with self.assertRaises(ValueError):
            add(e, event(e,'ENGAGE','g2',2,dependencies=['p1'],qualification_ref='qualification',force='high',compute='bounded',rationale='Continue'))

    def test_T12_capability_to_warranted_content(self):
        e = fixture()
        self.assertEqual(state(e)['prediction_state'], 'NOT_WARRANTED')
        observation(e)
        note(e)
        self.assertEqual(state(e)['prediction_state'], 'NOT_WARRANTED')
        add(e, rotate(e, possibilities=[possibility()], predictions=[prediction()]))
        self.assertEqual(state(e)['prediction_state'], 'AVAILABLE')

    def test_T13_possibility_without_prediction(self):
        e = ready()
        add(e, rotate(e, possibilities=[possibility(x) for x in ('a','b','c')]))
        self.assertEqual(len(state(e)['current']), 3)
        self.assertEqual(state(e)['prediction_state'], 'NOT_WARRANTED')

    def test_T14_QN02_intervention_attribution(self):
        for attribution in ('MEASUREMENT','INTERVENTION','UNRESOLVED'):
            e = fixture()
            observation(e)
            note(e, attribution=attribution)
            n = state(e)['notes']['n1']
            self.assertEqual(n['pre_state'], 'UNRESOLVED')
            self.assertEqual(n['induced_delta'], 'UNRESOLVED')
            self.assertEqual(n['attribution'], attribution)
            self.assertNotEqual(n['pre_state'], n['post_state'])

    def test_T15_false_north_is_challengeable(self):
        e = ready()
        add(e, rotate(e, possibilities=[possibility('north'), possibility('dependent',['north'])]))
        add(e, event(e,'CHALLENGE','c1',2,note_ids=['n1'],targets=['north'],qualification_ref='qualification',rationale='Strong contrary observation'))
        self.assertFalse(state(e)['current'])
        self.assertIn('north', state(e)['history'])

    def test_T16_compute_follows_qualified_error_surface(self):
        for compute in ('extensive high-risk qualification', 'minimal low-risk qualification'):
            e = ready()
            add(e, rotate(e, compute=compute))
            self.assertEqual(e['null_collapse']['events'][-1]['compute'], compute)

    def test_composition_identity_and_missing_gate(self):
        e = ready()
        self.assertEqual(gate.validate_composition(e), [])
        del e['null_collapse']
        self.assertTrue(gate.validate_composition(e))

    def test_malformed_and_ceiling(self):
        e = ready()
        self.assertTrue(gate.validate([], e['world_development']))
        p = possibility()
        p['standing'] = 'ESTABLISHED'
        with self.assertRaises(ValueError):
            add(e, rotate(e, possibilities=[p]))

    def test_exposure_cannot_use_unseen_observation(self):
        e = ready()
        e['null_collapse']['events'][0]['world_event_count'] = 0
        self.assertTrue(gate.validate(e['null_collapse'], e['world_development']))

    def test_horizon_expires_without_erasing_forecast(self):
        e = ready()
        add(e, rotate(e, possibilities=[possibility()], predictions=[prediction(horizon=2)]))
        add(e, rotate(e, eid='r2', tick=3))
        self.assertNotIn('f1', state(e)['current'])
        self.assertIn('f1', state(e)['history'])


    def test_foundation_failure_all_dependent_standing_moves(self):
        e = ready()
        add(e, rotate(e, possibilities=[possibility('a'), possibility('b',['a'])], predictions=[prediction(basis='b')]))
        add(e, event(e,'CHALLENGE','c1',2,note_ids=['n1'],targets=['a'],qualification_ref='qualification',rationale='Foundation lost'))
        self.assertFalse(state(e)['current'])
        self.assertEqual(len(state(e)['history']), 3)

    def test_requalification_reengages_with_new_identity(self):
        e = ready()
        add(e, rotate(e, possibilities=[possibility()]))
        add(e, event(e,'CHALLENGE','c1',2,note_ids=['n1'],targets=['p1'],qualification_ref='qualification',rationale='Reconsider'))
        add(e, rotate(e,eid='r2',tick=2,possibilities=[possibility('p2')]))
        add(e,event(e,'ENGAGE','g2',2,dependencies=['p2'],qualification_ref='qualification',force='high',compute='bounded',rationale='New warrant'))
        self.assertEqual(state(e)['engagements']['g2']['state'], 'CURRENT')
        self.assertIn('p1', state(e)['history'])

    def test_origin_substitution_fails(self):
        e = ready()
        e['null_collapse']['origin']['question'] = 'Easier replacement question'
        self.assertTrue(gate.validate_composition(e))

    def test_expired_prediction_cannot_warrant_engagement(self):
        e = ready()
        add(e, rotate(e, possibilities=[possibility()], predictions=[prediction(horizon=2)]))
        with self.assertRaises(ValueError):
            add(e,event(e,'ENGAGE','g1',3,dependencies=['f1'],qualification_ref='qualification',force='high',compute='bounded',rationale='Stale'))


if __name__ == '__main__':
    unittest.main()
