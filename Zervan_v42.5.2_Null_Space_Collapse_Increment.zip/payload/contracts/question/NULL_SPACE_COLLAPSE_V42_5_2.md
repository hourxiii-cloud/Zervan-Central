# v42.5.2 increment 03 — Null-Space Collapse / Observation-Analysis Separation

Target: consolidated vTemporal.42.5.2. Authority NONE. Human Gate ACTIVE.
Implementation: qualified-availability adapter composed with increments 01/02.
Source: full final candidate and supplied promotion record in change_requests/.

## Functional implementation

The governed Question remains the immutable originating commitment. Analysis,
qualifications, observed frames and forecasts remain related records outside Q.
Existing canonical observation intake supplies presence. Existing qualification
supplies attributable judgments. This adapter makes their different consequences
explicit and checks them at the composed Q/World/collapse entry point.

1. NOTE references an existing World OBSERVE event. Its acquired information,
   operation, pre-state, post-state, possible induced delta and attribution are
   preserved. Unknowns can remain UNRESOLVED. It creates no qualified claims.
2. ROTATE references prior notes, material reference standing, a QUALIFICATION
   receipt, an explicit frame assessment, rationale, independently recorded force
   and compute allocation. A qualified judgment can return no claims, several
   possibilities, or possibilities plus separately warranted predictions.
3. Replay emits every qualified prediction judgment in the operation that earns
   it. Possibility does not automatically generate prediction. Each prediction
   has a horizon, possibility basis, dependencies, notes and qualification lineage.
4. CHALLENGE accepts contradiction against prior reference or derived standing.
   Its delta invalidates current dependent standing transitively and expires
   dependent engagements. All original claims and observations remain in history.
5. ENGAGE records a warranted analytical engagement against current dependencies.
   It performs no external action and runs no persona, worker or callback. Force
   and compute are separate qualified fields with no numeric coupling or global
   minimum. Changed geometry requires a new warranted engagement record.
6. ACTUALIZE requires a distinct, subsequently noted observation and a qualified
   outcome interpretation. It records support, contradiction or uncertainty about
   the prediction; it never retroactively upgrades the original prediction basis.

QN-01: all AND ONLY materially dependent standing is reconsidered, including
transitive dependencies. Global dependence can invalidate all current claims.
QN-02: measurement/intervention/unresolved attribution remain distinct. The
presence of an observation operation or induced-delta field does not prove cause.

## Integration entry point

`tools/validate_null_collapse_v42_5_2.py` imports the installed World validator,
which calls the installed Box Question Return validator. The three components
share exact governed-object, operation, Box and originating-Question identity.
The envelope has exactly `box_question_return`, `world_development`, and
`null_collapse`. Missing the third component fails this entry point.

```bash
python3 tools/validate_null_collapse_v42_5_2.py RECORD.json --previous PRIOR.json
```

On success, the output exposes preserved Q, notes, current claims, historical
claims, requalification requirements, expired forecasts, engagements and outcome
observations. Call profile: `call/NULL_SPACE_COLLAPSE_V42_5_2.md`.

Standalone World representation operations remain valid for their existing
scope. Their validator alone is not evidence that qualified availability was
checked. Consumers claiming this increment's availability control must use the
composed entry point or the same `validate_composition` API.

## Representation and qualification choices

The adapter uses an append-only event list, not a new autonomous subsystem or a
mandatory linear analysis pipeline. NOTE may stop. ROTATE may produce no delta.
Any number of qualified alternatives may coexist. CHALLENGE is selective.
Different events may use prior qualified state without rebuilding it.

`tick` is an ordinal in the independently supplied FRAME receipt named by
`time_basis`. It is not generated time, wall time, or a universal clock. Different
frames require separately qualified normalization before entry. Historical event
time and observer effects remain available in the observation/receipt content.
`world_event_count` binds each operation to the World history exposed then;
later World facts cannot qualify earlier reference standing during replay.
A composed current output cannot silently ignore later World events.

Reference IDs use `world:<representation-id>` for separately qualified external
state, or earlier claim IDs for derived standing. Dependencies are declared
material reliance, not inferred causal edges. Requalification creates new claim
identities while retaining old invalidated identities and records. A redundant
independent support route should be represented by separate qualified claims;
invalidating one then preserves the other. The adapter does not assume two
routes are independent from their cardinality.

Claims cannot exceed either the supplied qualification ceiling or a material
dependency's ceiling. Forecast horizon expiration removes current availability,
not historical evidence. A challenge can target established reference standing.
No reference is immune because it once qualified.

## Native analytical operating contract

Observation earns presence, not geometry. Before using an observed framing as
analytical basis, identify the observed content, material supplied frame, actual
analytical position and independently qualified relationships. Retain uncertain
attribution, competing possibilities, contradictory reference states and null
prediction when earned. Qualify prediction availability separately from the
outcome; do not wait for the outcome after prediction warrant has been earned.

The qualification producer is responsible for distinguishing consideration from
qualified content: PMC may retain unqualified propositions for consideration
without this adapter assigning them standing. The gate's `current` claims are
qualified outputs; they are not the inventory of everything the system can think.
This preserves unfiltered consideration and prevents a closed-world reading of
Null. HERE binds the qualified result to Q, operation, temporal frame and exposure.

Error control comes before economy. Determine sufficient qualification depth
from the actual error surface. Preserve high force when warranted; spend extra
local compute when necessary; avoid fixed maximal processing for trivial cases.
Reassess geometry after consequential change. This contract governs analytical
selection; there is no new execution authority or background runtime.

## Source composition disposition

The final candidate extends functional availability controls. It does not rewrite
older source profiles. In particular:

- Possibility geometry being pre-existing does not mean particular unsupported
  forecasts were already instantiated as analytical content.
- The Box in Null names availability without unsupported population. It does not
  create a registry or compel materialization of a Box in every Null operation.
- North uses qualified external/temporal relation, with the reference itself
  requalifiable. It is not an oracle or a privileged immutable truth source.
- Qualified collapse delta changes standing. It is not an implementation of the
  World CR's unresolved condition-of-Box collapse into Reality.
- Originating Q remains in its governed Box. Noting, rotation, collapse metadata
  and predictive outputs remain outside Q and return with preserved identity.

These are implementation bindings, not retroactive amendments of frozen sources
or resolutions of their metaphysical or formal unresolveds.

## Evidence limits

Qualification receipts, time frames, relevance, dependency completeness, risk,
force and compute judgments are supplied by the governed analytical/Human
qualification process. This adapter checks linkage, ordering, ceilings and state
consequences. It cannot establish their semantic correctness or authenticity.
A nonempty rationale is not proof that an observation was independently assessed.
T3/T4/T6/T10/T16 executable tests exercise correct handling of supplied judgments;
they do not show a language model independently deriving those judgments.

The original conversational T1–T16 PASS and Human approval are archived as source
provenance. Local executable tests are separately recorded. Neither is silently
substituted for the other. Timing claims require truthful independently qualified
time/exposure records; the adapter cannot discover forged clocks or coordinated
rewrites of every historical copy. Supply a trusted prior snapshot for history
comparison. No statistical calibration or universal hallucination prevention is
claimed. Existing v42.5.1 files and VERSION markers are not rewritten by increment
installation during the ongoing consolidated review.
