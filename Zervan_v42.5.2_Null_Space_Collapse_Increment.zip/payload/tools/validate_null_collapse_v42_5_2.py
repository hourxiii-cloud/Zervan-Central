#!/usr/bin/env python3
"""Qualified availability adapter over the existing World/Box record.

Qualification is a supplied, attributable judgment, not inferred from text.
Replay enforces its consequences; it does not certify source or judgment truth.
No external calls, callbacks, clock creation, or originating-data mutations.
"""
from copy import deepcopy
import importlib.util
import json
from pathlib import Path

_spec = importlib.util.spec_from_file_location('world_box_gate_dependency', Path(__file__).with_name('validate_world_box_v42_5_2.py'))
world = importlib.util.module_from_spec(_spec)
_spec.loader.exec_module(world)
InvalidRecord = world.InvalidRecord
require, shape, text, strings = world.require, world.shape, world.text, world.strings


def start(origin):
    return {'format': 'NULL_COLLAPSE_1', 'origin': deepcopy(origin),
            'authority': 'NONE', 'human_gate': 'ACTIVE', 'events': []}


def replay(record, world_record):
    failures = world.validate(world_record)
    require(not failures, 'World record: ' + '; '.join(failures))
    ws = world.replay(world_record)
    receipts = world.receipt_map(world_record['receipts'])
    shape(record, 'format origin authority human_gate events', 'collapse record')
    require(record['format'] == 'NULL_COLLAPSE_1', 'format')
    require(record['origin'] == world_record['origin'], 'origin substitution')
    require(record['authority'] == 'NONE' and record['human_gate'] == 'ACTIVE', 'authority boundary')
    require(type(record['events']) is list, 'events must be list')
    notes, claims, engagements, actualizations = {}, {}, {}, {}
    seen, invalid, challenges = set(), set(), []
    last_tick, time_basis, last_world_count = None, None, 0

    def ref(key, role):
        text(key, role)
        require(key in receipts and receipts[key]['role'] == role, 'missing ' + role + ' receipt')
        return receipts[key]

    def dependency(key):
        text(key, 'dependency')
        if key.startswith('world:'):
            rid = key[6:]
            require(rid in ws['standings'] and ws['standings'][rid] in {'SUPPORTED', 'ESTABLISHED'}, 'reference is not qualified')
        else:
            require(key in claims, 'dependency is not earlier standing')
        require(key not in invalid, 'dependency requires requalification')
        if key in claims and claims[key]['kind'] == 'PREDICTION':
            require(claims[key]['horizon'] >= last_tick, 'prediction dependency expired')

    def propagate(roots):
        affected = set(roots)
        while True:
            extra = {k for k, v in claims.items() if set(v['dependencies']) & affected}
            if extra <= affected:
                break
            affected |= extra
        invalid.update(affected)
        for e in engagements.values():
            if set(e['dependencies']) & affected:
                e['state'] = 'EXPIRED'
        return sorted(affected)

    for e in record['events']:
        require(type(e) is dict, 'event must be object')
        kind = e.get('type')
        keys = {
            'NOTE': 'observation_id observation_operation pre_state post_state induced_delta attribution',
            'ROTATE': 'note_ids reference_ids qualification_ref rationale frame_assessment possibilities predictions compute force',
            'CHALLENGE': 'note_ids targets qualification_ref rationale',
            'ENGAGE': 'dependencies qualification_ref force compute rationale',
            'ACTUALIZE': 'prediction_id note_id qualification_ref outcome rationale',
        }
        require(type(kind) is str and kind in keys, 'unsupported event type')
        shape(e, 'id type tick time_basis contribution_ref world_event_count ' + keys[kind], kind)
        require(type(e['world_event_count']) is int and last_world_count <= e['world_event_count'] <= len(world_record['events']), 'invalid or reversed World exposure')
        last_world_count = e['world_event_count']
        exposed = deepcopy(world_record)
        exposed['events'] = exposed['events'][:last_world_count]
        ws = world.replay(exposed)
        for rid, standing in ws['standings'].items():
            if standing not in {'SUPPORTED', 'ESTABLISHED'} and any('world:' + rid in c['dependencies'] for c in claims.values()):
                propagate(['world:' + rid])
        text(e['id'], 'id')
        require(e['id'] not in seen and e['id'] not in claims, 'duplicate id')
        require(type(e['tick']) is int, 'tick must be qualified ordinal integer')
        ref(e['time_basis'], 'FRAME')
        ref(e['contribution_ref'], 'CONTRIBUTION')
        if time_basis is None:
            time_basis = e['time_basis']
        require(e['time_basis'] == time_basis, 'different time frames require separately qualified normalization')
        require(last_tick is None or e['tick'] >= last_tick, 'operation order rewritten')
        last_tick = e['tick']
        if kind == 'NOTE':
            text(e['observation_id'], 'observation id')
            require(e['observation_id'] in ws['observations'], 'NOTE must reference an observation, not representation')
            require(e['observation_id'] not in {n['observation_id'] for n in notes.values()}, 'observation noted twice')
            for k in ('observation_operation', 'pre_state', 'post_state', 'induced_delta'):
                text(e[k], k)
            require(e['attribution'] in ('MEASUREMENT', 'INTERVENTION', 'UNRESOLVED'), 'attribution must retain standing')
            # These fields record attribution, not a causal certification.
            notes[e['id']] = deepcopy(e)
        elif kind in ('ROTATE', 'CHALLENGE'):
            strings(e['note_ids'], 'note_ids')
            require(e['note_ids'] and set(e['note_ids']) <= notes.keys(), 'noting required before rotation')
            q = ref(e['qualification_ref'], 'QUALIFICATION')
            text(e['rationale'], 'qualification rationale')
            if kind == 'CHALLENGE':
                strings(e['targets'], 'targets')
                require(e['targets'], 'empty challenge')
                for target in e['targets']:
                    # Previously invalid references may be challenged again; no immunity.
                    require(target in claims or (target.startswith('world:') and target[6:] in ws['representations']), 'unknown challenged reference')
                challenges.append({'event_id': e['id'], 'affected': propagate(e['targets']), 'rationale': e['rationale']})
            else:
                strings(e['reference_ids'], 'reference_ids')
                for rid in e['reference_ids']:
                    dependency(rid)
                text(e['frame_assessment'], 'frame assessment')
                text(e['compute'], 'qualified compute allocation')
                text(e['force'], 'qualified analytical force')
                for group in ('possibilities', 'predictions'):
                    require(type(e[group]) is list, group + ' must be list')
                for group in ('possibilities', 'predictions'):
                    for item in e[group]:
                        shape(item, 'id content standing dependencies' + (' horizon possibility_ids' if group == 'predictions' else ''), group)
                        text(item['id'], 'claim id')
                        require(item['id'] not in claims and item['id'] not in seen and item['id'] != e['id'], 'duplicate claim id')
                        text(item['content'], 'content')
                        require(item['standing'] in ('SUPPORTED', 'ESTABLISHED'), 'availability needs positive qualification')
                        require(world.RANK[item['standing']] <= world.RANK[q['ceiling']], 'claim exceeds qualification ceiling')
                        strings(item['dependencies'], 'dependencies')
                        for d in item['dependencies']:
                            dependency(d)
                            ceiling = ws['standings'][d[6:]] if d.startswith('world:') else claims[d]['standing']
                            require(world.RANK[item['standing']] <= world.RANK[ceiling], 'claim exceeds dependency ceiling')
                        require(set(e['reference_ids']) <= set(item['dependencies']), 'reference dependence omitted')
                        if group == 'predictions':
                            strings(item['possibility_ids'], 'possibility_ids')
                            require(item['possibility_ids'], 'prediction needs qualified possibility')
                            for p in item['possibility_ids']:
                                dependency(p)
                                require(claims[p]['kind'] == 'POSSIBILITY', 'prediction basis is not possibility')
                            require(set(item['possibility_ids']) <= set(item['dependencies']), 'prediction dependency omitted')
                            require(type(item['horizon']) is int and item['horizon'] > e['tick'], 'post hoc or expired prediction horizon')
                        claims[item['id']] = dict(deepcopy(item), kind='PREDICTION' if group == 'predictions' else 'POSSIBILITY',
                                                 event_id=e['id'], tick=e['tick'], note_ids=list(e['note_ids']),
                                                 qualification_ref=e['qualification_ref'])
                # Qualified prediction judgments become outputs in this operation;
                # no optional emission step can silently suppress them.
        elif kind == 'ENGAGE':
            strings(e['dependencies'], 'dependencies')
            require(e['dependencies'], 'engagement requires geometry')
            for d in e['dependencies']:
                dependency(d)
            q = ref(e['qualification_ref'], 'QUALIFICATION')
            require(q['ceiling'] in ('SUPPORTED', 'ESTABLISHED'), 'engagement warrant absent')
            for k in ('force', 'compute', 'rationale'):
                text(e[k], k)
            engagements[e['id']] = dict(deepcopy(e), state='CURRENT')
        else:
            require(e['prediction_id'] in claims and claims[e['prediction_id']]['kind'] == 'PREDICTION', 'not a recorded prediction')
            require(e['note_id'] in notes, 'actualization needs new observation')
            p, n = claims[e['prediction_id']], notes[e['note_id']]
            require(n['tick'] > p['tick'] and e['tick'] >= n['tick'], 'outcome observation must follow prediction')
            require(e['note_id'] not in p['note_ids'], 'forecast input reused as outcome')
            q = ref(e['qualification_ref'], 'QUALIFICATION')
            require(e['outcome'] in ('SUPPORTED', 'CONTRADICTED', 'UNRESOLVED'), 'invalid outcome standing')
            require(e['outcome'] == 'UNRESOLVED' or q['ceiling'] in ('SUPPORTED', 'ESTABLISHED'), 'outcome exceeds qualification')
            text(e['rationale'], 'outcome rationale')
            actualizations[e['id']] = deepcopy(e)
            if e['outcome'] != 'UNRESOLVED':
                propagate([e['prediction_id']])
            # Outcome never edits the original availability judgment.
        seen.add(e['id'])
    # Do not silently ignore new World evidence at the composed boundary.
    require(last_world_count == len(world_record['events']) or not world_record['events'], 'World changes require current exposure/requalification')
    expired = {k for k, v in claims.items() if v['kind'] == 'PREDICTION' and last_tick is not None and v['horizon'] < last_tick}
    propagate(expired)
    current = {k: deepcopy(v) for k, v in claims.items() if k not in invalid and k not in expired}
    return {'question': record['origin']['question'], 'notes': notes, 'history': claims,
            'current': current, 'requalification_required': sorted(invalid),
            'expired_predictions': sorted(expired), 'challenges': challenges, 'engagements': engagements, 'actualizations': actualizations,
            'prediction_state': 'AVAILABLE' if any(c['kind'] == 'PREDICTION' for c in current.values()) else 'NOT_WARRANTED'}


def validate(record, world_record, previous=None):
    try:
        replay(record, world_record)
        if previous is not None:
            for key in ('format', 'origin', 'authority', 'human_gate'):
                require(record[key] == previous[key], 'origin or governance history rewritten')
            require(record['events'][:len(previous['events'])] == previous['events'], 'collapse history rewritten')
        return []
    except (ValueError, TypeError, KeyError, AttributeError) as exc:
        return [str(exc)]


def append_event(record, world_record, event):
    prior_world = deepcopy(world_record)
    count = record['events'][-1]['world_event_count'] if record.get('events') else 0
    prior_world['events'] = prior_world['events'][:count]
    require(not validate(record, prior_world), 'invalid input record')
    result = deepcopy(record)
    result['events'].append(deepcopy(event))
    failures = validate(result, world_record, record)
    require(not failures, '; '.join(failures))
    return result


def validate_composition(envelope, previous=None):
    try:
        shape(envelope, 'box_question_return world_development null_collapse', 'qualified composition')
        core = {k: envelope[k] for k in ('box_question_return', 'world_development')}
        failures = world.validate_composition(core, previous['world_development'] if previous else None)
        require(not failures, 'Q/World composition: ' + '; '.join(failures))
        failures = validate(envelope['null_collapse'], envelope['world_development'], previous['null_collapse'] if previous else None)
        require(not failures, 'qualified collapse: ' + '; '.join(failures))
        return []
    except (ValueError, TypeError, KeyError, AttributeError) as exc:
        return [str(exc)]


def main():
    import argparse
    p = argparse.ArgumentParser(description=__doc__)
    p.add_argument('record', type=Path)
    p.add_argument('--previous', type=Path)
    args = p.parse_args()
    try:
        record = json.loads(args.record.read_text())
        previous = json.loads(args.previous.read_text()) if args.previous else None
        errors = validate_composition(record, previous)
        if errors:
            print('\n'.join(errors))
            return 1
        print(json.dumps(replay(record['null_collapse'], record['world_development']), indent=2))
        return 0
    except (OSError, ValueError, TypeError, KeyError) as exc:
        print('INVALID: ' + str(exc))
        return 1


if __name__ == '__main__':
    raise SystemExit(main())
