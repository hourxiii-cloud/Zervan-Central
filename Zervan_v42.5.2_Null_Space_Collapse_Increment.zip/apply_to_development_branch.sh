#!/usr/bin/env bash
set -euo pipefail
repo=$(realpath -- "${1:?Pass repository root}")
package=$(cd -- "$(dirname -- "${BASH_SOURCE[0]}")" && pwd)
[[ "$(git -C "$repo" rev-parse --show-toplevel)" == "$repo" ]] || exit 2
[[ "$(git -C "$repo" branch --show-current)" == development/v42.5.2 ]] || {
  echo 'Switch to development/v42.5.2 before applying.' >&2; exit 2;
}
git -C "$repo" merge-base --is-ancestor 65df9336f869e5f0c82ded5e50c8c7dca9f7f2d5 HEAD || {
  echo 'Required canonical ancestor missing.' >&2; exit 2;
}
git -C "$repo" diff --quiet && git -C "$repo" diff --cached --quiet || {
  echo 'Commit or preserve tracked working changes first.' >&2; exit 2;
}
(cd "$package" && sha256sum -c SHA256SUMS)
(cd "$repo" && sha256sum -c "$package/PREREQUISITES.sha256")
python3 - "$package" "$repo" <<'PY'
from pathlib import Path
import sys
package, repo = map(Path, sys.argv[1:])
paths = (package/'FILES').read_text().splitlines()
for relative in paths:
    p = Path(relative)
    if p.is_absolute() or '..' in p.parts or not p.parts:
        raise SystemExit('Unsafe manifest path')
    target, source = repo/p, package/'payload'/p
    if not target.resolve().is_relative_to(repo) or target.is_symlink():
        raise SystemExit('Unsafe destination: '+relative)
    if target.exists() and (not target.is_file() or target.read_bytes() != source.read_bytes()):
        raise SystemExit('Existing different file; nothing copied: '+relative)
for relative in paths:
    target = repo/relative
    target.parent.mkdir(parents=True, exist_ok=True)
    target.write_bytes((package/'payload'/relative).read_bytes())
print('Installed qualified-collapse increment. Running composed regression.')
PY
cd "$repo"
python3 -m unittest discover -s tests -p 'test_*v42_5_2.py' -v
python3 tools/validate_null_collapse_v42_5_2.py verification/v42.5.2/NULL_COLLAPSE_COMPOSITION_EXAMPLE.json >/dev/null
git diff --check
echo 'Integration and tests passed. Ready to commit the files listed in FILES.'
