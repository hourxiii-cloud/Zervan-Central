#!/usr/bin/env bash
set -euo pipefail

BRANCH="candidate/v42.5.1-temporal-compute"
COMMIT="c1854b2"
OUT="Zervan_v42.5.1_Temporal_Compute_Candidate.zip"
STAGE=".v42_5_1_export"

[ "$(git branch --show-current)" = "$BRANCH" ] || {
  echo "ABORT: expected branch $BRANCH"
  exit 1
}

git rev-parse --verify "$COMMIT^{commit}" >/dev/null

required=(
  "call/INITIATION_STATEMENT_V42_5_1_CANDIDATE.md"
  "candidate/v42.5.1/ANALYTICAL_QUALITY_INVARIANT_COMPUTE_SUFFICIENCY_BOUNDARY.md"
  "candidate/v42.5.1/MANIFEST.json"
  "candidate/v42.5.1/TEMPORAL_COMPUTE_AVAILABILITY_FROZEN_SOURCE.md"
  "candidate/v42.5.1/TEMPORAL_COMPUTE_CANONICAL_IMPLEMENTATION.md"
  "change_requests/CR_v42_5_1_TEMPORAL_COMPUTE_RUNTIME_INDEPENDENT_CONTINUITY.md"
  "verification/v42.5.1/V42_5_1_VALIDATION_PLAN.md"
)

rm -rf "$STAGE"
mkdir -p "$STAGE"

for f in "${required[@]}"; do
  git cat-file -e "$COMMIT:$f" || {
    echo "ABORT: $f is not present in commit $COMMIT"
    exit 1
  }
  mkdir -p "$STAGE/$(dirname "$f")"
  git show "$COMMIT:$f" > "$STAGE/$f"
done

git format-patch -1 "$COMMIT" --stdout > "$STAGE/v42.5.1-c1854b2.patch"

cat > "$STAGE/TRANSFER_MANIFEST.txt" <<EOF
Zervan v42.5.1 Temporal Compute Candidate
Branch: $BRANCH
Commit: $COMMIT
Parent: $(git rev-parse "$COMMIT^")
Canonical parent identity: vTemporal.42.5.0

Package contains:
- exact repository files from commit $COMMIT
- a format-patch representation of commit $COMMIT

Intentionally excluded:
- VERSION mutation
- VERSION.json mutation
- VERSION_AUTHORITY.md mutation
- canonical promotion entry
- promotion receipt

Reason:
v42.5.1 remains candidate pending V01-V16, hostile validation,
aggregate validation, qualification, Human Gate, and promotion.
EOF

(
  cd "$STAGE"
  find . -type f -print0 | sort -z | xargs -0 sha256sum > SHA256SUMS.txt
  zip -qr "../$OUT" .
)

rm -rf "$STAGE"

echo
echo "CREATED: $OUT"
echo
unzip -l "$OUT"
