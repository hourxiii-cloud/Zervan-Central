# Zervan v42.5.1 Temporal Compute Transfer Package

Candidate branch:
`candidate/v42.5.1-temporal-compute`

Candidate commit:
`c1854b2`

Canonical parent:
`vTemporal.42.5.0`

Canonical parent commit:
`de79c24aef044dc57f13a980c8ca0be25e14f4b6`

This package is designed to be placed in the root of the existing Zervan-Central Codespace/repository.

Run:

```bash
bash EXPORT_v42_5_1_FROM_CODESPACES.sh
```

That script verifies the candidate branch and commit, then creates an exact ZIP of the seven committed v42.5.1 candidate artifacts plus a Git patch for commit `c1854b2`.

No canonical promotion artifacts are added by this package. `VERSION`, `VERSION.json`, `VERSION_AUTHORITY.md`, canonical entry, and promotion receipt remain untouched until validation/qualification/Human Gate are complete.
