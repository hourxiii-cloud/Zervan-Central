#!/usr/bin/env bash
set -euo pipefail

ZIP="${1:-v42.5_FINAL_CLOSURE_PACKAGE.zip}"
REPO="${2:-.}"
EXPECTED_BRANCH="candidate/v42.5"
TMP="$(mktemp -d)"
trap 'rm -rf "$TMP"' EXIT

abort() { echo; echo "=== v42.5 PACKAGE CATCH ABORT ==="; echo "$1"; echo; exit 1; }

cd "$REPO"
[ "$(git branch --show-current)" = "$EXPECTED_BRANCH" ] || abort "Expected $EXPECTED_BRANCH."
[ -f "$ZIP" ] || abort "Package not found: $ZIP"

python - "$ZIP" "$TMP" <<'PY'
from pathlib import Path
from zipfile import ZipFile, BadZipFile
import sys
z=Path(sys.argv[1]); out=Path(sys.argv[2])
try:
    with ZipFile(z) as f:
        names=f.namelist()
        if any('install_v42_4_closure' in n or 'v42.4_FINAL_CLOSURE_PACKAGE' in n for n in names):
            raise SystemExit('ABORT: v42.4 closure body detected inside v42.5 filename.')
        required_suffixes=[
            'change_requests/CR_v42_5_PRESERVED_ANALYTICAL_ORIENTATION_NATIVE_EXTERNAL_MANEUVER_OPERATION_BOUND_ACCESS.md',
            'candidate/v42.5/PRESERVED_ANALYTICAL_ORIENTATION_NATIVE_EXTERNAL_MANEUVER_OPERATION_BOUND_ACCESS_IMPLEMENTATION.md',
            'scripts/DEPLOY_V42_5_QUALIFIED.sh',
            'verification/v42.5/V42_5_QUALIFICATION_DISPOSITION.md',
        ]
        for req in required_suffixes:
            if not any(n.endswith(req) for n in names):
                raise SystemExit('ABORT: required package member missing: '+req)
        f.extractall(out)
except BadZipFile:
    raise SystemExit('ABORT: invalid ZIP.')
PY

PKG_DIR="$(find "$TMP" -type f -path '*/scripts/DEPLOY_V42_5_QUALIFIED.sh' -print -quit | xargs -r dirname | xargs -r dirname)"
[ -n "$PKG_DIR" ] || abort "Could not resolve extracted v42.5 package root."

grep -Fq '# CR-v42.5 — PRESERVED ANALYTICAL ORIENTATION / NATIVE EXTERNAL MANEUVER / OPERATION-BOUND ACCESS' \
  "$PKG_DIR/change_requests/CR_v42_5_PRESERVED_ANALYTICAL_ORIENTATION_NATIVE_EXTERNAL_MANEUVER_OPERATION_BOUND_ACCESS.md" \
  || abort "Frozen CR title mismatch."

bash "$PKG_DIR/scripts/DEPLOY_V42_5_QUALIFIED.sh" "$PWD"
