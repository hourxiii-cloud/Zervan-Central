#!/usr/bin/env bash
set -euo pipefail
REPO_ROOT="${1:-.}"
PKG_DIR="$(cd "$(dirname "$0")/.." && pwd)"
cd "$REPO_ROOT"

if [ "$(git branch --show-current)" != "main" ]; then
  echo "ABORT: promotion requires main"
  exit 1
fi

QUALIFICATION_COMMIT="$(git log -1 --format=%H -- verification/v42.5/V42_5_QUALIFICATION_DISPOSITION.md)"
if [ -z "$QUALIFICATION_COMMIT" ]; then
  echo "ABORT: qualification commit cannot be resolved"
  exit 1
fi

# Human Gate must be explicit outside this script.
cp "$PKG_DIR/VERSION.candidate" VERSION
cp "$PKG_DIR/VERSION.json.candidate" VERSION.json

python - "$QUALIFICATION_COMMIT" <<'PY2'
from pathlib import Path
import json, sys
q=sys.argv[1]

# VERSION.json
p=Path('VERSION.json')
j=json.loads(p.read_text())
j['promotion_state']='CANONICAL'
j['canonical']=True
j['qualification_commit']=q
p.write_text(json.dumps(j, indent=2)+'\n')

# canonical entry
p=Path('canonical/ZERVAN_v42_5_0_CANONICAL_ENTRY.md')
s=p.read_text()
s=s.replace('Status: CANDIDATE PROMOTION SURFACE — DO NOT TREAT AS CANONICAL UNTIL HUMAN GATE PROMOTION','Status: CANONICAL')
s=s.replace('QUALIFICATION_COMMIT_RESOLVED_AT_PROMOTION', q)
p.write_text(s)

# authority block, append as canonicalized section
src=Path('VERSION_AUTHORITY_APPEND_v42_5.md').read_text()
src=src.replace('# VERSION AUTHORITY — v42.5 CANDIDATE PROMOTION APPENDIX','# v42.5.0 canonical standing')
src=src.replace('This package is qualified for Human-gated canonical promotion but is not self-promoting.','This section records the Human Gate-authorized v42.5.0 canonical standing.')
src=src.replace('Before promotion:\n- Promotion State: QUALIFIED FOR HUMAN-GATED CANONICAL PROMOTION\n- Canonical: FALSE\n\nAfter explicit Human Gate promotion and repository movement:\n- Promotion State: CANONICAL\n- Canonical: TRUE\n- Canonical Branch: main\n','Promotion State: CANONICAL\nCanonical: TRUE\nCanonical Branch: main\n')
src=src.replace('QUALIFICATION_COMMIT_RESOLVED_AT_PROMOTION', q)
with Path('VERSION_AUTHORITY.md').open('a') as f:
    f.write('\n---\n\n')
    f.write(src)
PY2

git add VERSION VERSION.json VERSION_AUTHORITY.md canonical/ZERVAN_v42_5_0_CANONICAL_ENTRY.md call/INITIATION_STATEMENT_V42_5_0.md
git commit -m "promote(v42.5.0): canonicalize observation orientation and native external maneuver"
PROMOTION_COMMIT="$(git rev-parse HEAD)"

mkdir -p receipts/v42.5
cat > receipts/v42.5/CANONICAL_PROMOTION_RECEIPT.md <<EOF
# v42.5.0 CANONICAL PROMOTION RECEIPT

Promotion Commit: \`$PROMOTION_COMMIT\`  
Qualification Commit: \`$QUALIFICATION_COMMIT\`  
Canonical Branch: main  
Authority: NONE  
Human Gate: ACTIVE  
No Compression Out: ACTIVE
EOF

git add receipts/v42.5/CANONICAL_PROMOTION_RECEIPT.md
git commit -m "receipt(v42.5.0): record resolved canonical promotion"

echo "QUALIFICATION: $QUALIFICATION_COMMIT"
echo "PROMOTION:     $PROMOTION_COMMIT"
echo "RECEIPT HEAD:  $(git rev-parse HEAD)"
