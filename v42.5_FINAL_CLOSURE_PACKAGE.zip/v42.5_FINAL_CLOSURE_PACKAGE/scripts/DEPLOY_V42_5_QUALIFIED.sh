#!/usr/bin/env bash
set -euo pipefail

REPO_ROOT="${1:-.}"
PKG_DIR="$(cd "$(dirname "$0")/.." && pwd)"
cd "$REPO_ROOT"

EXPECTED_BRANCH="candidate/v42.5"
EXPECTED_PARENT="b080ffeea6d590765acdb14a82124e511e57afd0"
CR="change_requests/CR_v42_5_PRESERVED_ANALYTICAL_ORIENTATION_NATIVE_EXTERNAL_MANEUVER_OPERATION_BOUND_ACCESS.md"
IMPL="candidate/v42.5/PRESERVED_ANALYTICAL_ORIENTATION_NATIVE_EXTERNAL_MANEUVER_OPERATION_BOUND_ACCESS_IMPLEMENTATION.md"

abort() { echo; echo "=== v42.5 INGEST ABORT ==="; echo "$1"; echo; exit 1; }

[ "$(git branch --show-current)" = "$EXPECTED_BRANCH" ] || abort "Expected $EXPECTED_BRANCH."
[ -z "$(git status --porcelain)" ] || abort "Working tree is not clean."
git fetch origin main >/dev/null 2>&1 || abort "Could not fetch origin/main."
[ "$(git rev-parse origin/main)" = "$EXPECTED_PARENT" ] || abort "origin/main moved from validated v42.4 parent. Revalidation required."
[ "$(git merge-base "$EXPECTED_PARENT" HEAD)" = "$EXPECTED_PARENT" ] || abort "candidate/v42.5 is not descended from validated v42.4 parent."

# Package identity guards. A v42.4 body renamed as v42.5 must fail here.
[ -f "$PKG_DIR/$CR" ] || abort "Correct frozen CR is missing from package."
[ -f "$PKG_DIR/$IMPL" ] || abort "Correct v42.5 implementation is missing from package."
if find "$PKG_DIR" -type f -maxdepth 4 -print0 | xargs -0 grep -Ilq 'install_v42_4_closure\|v42\.4_FINAL_CLOSURE_PACKAGE'; then
  abort "v42.4 closure content detected inside v42.5 package."
fi
grep -Fq '# CR-v42.5 — PRESERVED ANALYTICAL ORIENTATION / NATIVE EXTERNAL MANEUVER / OPERATION-BOUND ACCESS' "$PKG_DIR/$CR" || abort "Frozen CR title mismatch."

copy_file() {
  src="$PKG_DIR/$1"
  dst="$1"
  mkdir -p "$(dirname "$dst")"
  cp "$src" "$dst"
}

# 1 — Frozen CR + captured development register
copy_file "$CR"
copy_file candidate/v42.5/CAPTURED_DEVELOPMENT_REGISTER.md
git add "$CR" candidate/v42.5/CAPTURED_DEVELOPMENT_REGISTER.md
git commit -m "stage(v42.5): preserve full clean frozen CR"

# 2 — Revised implementation
copy_file "$IMPL"
git add "$IMPL"
git commit -m "implement(v42.5): preserved analytical orientation, native external maneuver, and operation-bound access"

# 3 — Individual validations, hostile suite, revision lineage
mkdir -p verification/v42.5
for f in "$PKG_DIR"/verification/v42.5/*.md; do
  rel="${f#$PKG_DIR/}"
  copy_file "$rel"
done

git add verification/v42.5
git commit -m "validate(v42.5): close individual validation and hostile suite"

# 4 — Promotion surfaces remain staged, not canonicalized
copy_file call/INITIATION_STATEMENT_V42_5_0.md
copy_file canonical/ZERVAN_v42_5_0_CANONICAL_ENTRY.md
copy_file VERSION_AUTHORITY_APPEND_v42_5.md
git add call/INITIATION_STATEMENT_V42_5_0.md canonical/ZERVAN_v42_5_0_CANONICAL_ENTRY.md VERSION_AUTHORITY_APPEND_v42_5.md
git commit -m "stage(v42.5.0): human-gated canonical promotion surfaces"

cat <<'EOF'

=== v42.5 CANDIDATE INGEST COMPLETE ===
Frozen CR: PRESENT
Captured development: PRESENT
Revised implementation: PRESENT
Individual validation artifacts: PRESENT
Hostile/revision/aggregate/qualification artifacts: PRESENT
Promotion surfaces: STAGED
Canonical main mutation: NONE
VERSION switch: NOT PERFORMED
Human Gate promotion: NOT PERFORMED

Next: inspect candidate/v42.5 HEAD and qualification lineage before merge/promotion.
EOF
