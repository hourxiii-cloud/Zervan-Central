# v42.2.0 Canonical Lineage

Parent canonical identity:
vTemporal.42.1.1
main @ 7cb608854f91ca6f70ae9430815ebf928ed3df48

Qualified lineage:

CR-1 — Harmony Temporal Contraction / Restriction
Disposition: PASS
Preserved distinction: ΔO != ΔQ

CR-2R — Harmony Temporal Relationship / Möbius Traversal / Root-Cause Qualification
Disposition: PASS
CR-2: superseded by CR-2R
Preserved distinctions:
- Precedence != Causation
- Temporal preservation != Temporal maneuver
- Q_ti != Q_current(ti) when later evidence changes current standing concerning ti

CR-3 — Harmony Temporal / Möbius Composition & Collapse Review
Disposition: PASS — COMPOSITION WITH EMERGENT OBJECT

Emergent object:
RELATIONAL STATE TRAJECTORY

No constituent object is erased by composition.
No prior review package is rewritten by canonical application.
