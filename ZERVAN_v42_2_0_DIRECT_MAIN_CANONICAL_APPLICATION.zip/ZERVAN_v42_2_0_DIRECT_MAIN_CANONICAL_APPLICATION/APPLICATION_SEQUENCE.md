# Direct Main Application Sequence

This document defines the bounded repository movement. It is not an additional analytical test cycle.

## Preflight

Immediately before writes:
- fetch origin;
- switch to main;
- fast-forward main from origin/main;
- verify branch == main;
- verify HEAD == 7cb608854f91ca6f70ae9430815ebf928ed3df48;
- verify VERSION == vTemporal.42.1.1;
- verify worktree clean.

Any mismatch: STOP and preserve state.

## Canonical integration surfaces

Use the repository's current v42.1.1 native architecture as the implementation template.

The application SHALL update the complete active identity family consistently, including where present:
- VERSION
- VERSION.json
- VERSION_AUTHORITY.md
- VERSION_REFERENCES.json
- active initiation statement
- active canonical entry
- version-validation/reference tooling and tests whose contracts require the new identity
- promotion/closure/receipt surfaces required by the current canonical architecture

Do not replay the historical v42 promotion patch.

Do not rewrite CR-1 or CR-2R package contents.

## Required canonical identity

Version: vTemporal.42.2.0
Canonical branch: main
Promotion State: CANONICAL
Canonical: TRUE
Authority: NONE
Human Gate: ACTIVE
Control State: CONTROLLED / CANONICAL / PROMOTED / ACTIVATED

## Integration verification

After application, verify:
- all active version surfaces agree on vTemporal.42.2.0;
- canonical entry and initiation statement resolve;
- lineage points to vTemporal.42.1.1 and the CR-1 / CR-2R / CR-3 qualified development;
- required Relational State Trajectory invariants are represented;
- no prior canonical history or review artifact was rewritten;
- Authority NONE;
- Human Gate ACTIVE;
- worktree contains only intended application changes before commit.

This is application verification, not redundant proposition requalification.

## Commit and push

Commit the bounded canonical application on main only after the integration verification above succeeds.

Push main normally. No force push.

After push, resolve and record the exact resulting main commit. The promotion commit SHALL NOT be predeclared.
